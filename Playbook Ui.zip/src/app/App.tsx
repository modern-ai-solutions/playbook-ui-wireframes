import { useState } from 'react';
import { ProjectsOverview } from './components/ProjectsOverview';
import { CreateWorkflow } from './components/CreateWorkflow';
import { ViewPlaybook } from './components/ViewPlaybook';

export default function App() {
  const [currentView, setCurrentView] = useState<'overview' | 'create' | 'view'>('overview');
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | null>(null);

  const handleViewPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('view');
  };

  return (
    <div className="size-full bg-[#E8EDE8]">
      {currentView === 'overview' && (
        <ProjectsOverview 
          onCreateNew={() => setCurrentView('create')} 
          onViewPlaybook={handleViewPlaybook}
        />
      )}
      {currentView === 'create' && <CreateWorkflow onBack={() => setCurrentView('overview')} />}
      {currentView === 'view' && selectedPlaybookId && (
        <ViewPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
        />
      )}
    </div>
  );
}