import { FileText, ListChecks, Plus, Eye, CheckCircle2, Share2 } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

interface HomepageProps {
  onNavigateToPlaybooks: () => void;
  onNavigateToInstances: () => void;
  onCreatePlaybook: () => void;
}

export function Homepage({ onNavigateToPlaybooks, onNavigateToInstances, onCreatePlaybook }: HomepageProps) {
  return (
    <div className="h-full flex flex-col overflow-auto bg-[#E8EDE8]">
      {/* Header */}
      <div className="px-12 pt-16 pb-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-[#006B7D] mb-3" style={{ fontSize: '36px', fontWeight: 600 }}>
            Playbooks
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl">
            Create reusable playbooks and manage workflow instances with AI-powered insights
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-12 pb-16">
        <div className="max-w-6xl mx-auto">
          {/* Library Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {/* Playbook Library Card */}
            <Card className="bg-white border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-lg bg-[#006B7D] flex items-center justify-center">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-gray-900">Playbook Library</h2>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Create and manage reusable workflow templates for document analysis. Define questions once and use them across multiple documents.
                </p>
                
                <div className="space-y-3">
                  <Button
                    onClick={onNavigateToPlaybooks}
                    className="w-full bg-[#006B7D] hover:bg-[#005568] text-white h-12 text-base font-medium"
                  >
                    <Eye className="w-5 h-5 mr-2" />
                    View Playbooks
                  </Button>
                  <Button
                    onClick={onCreatePlaybook}
                    variant="outline"
                    className="w-full border-[#006B7D] text-[#006B7D] hover:bg-[#006B7D]/10 h-12 text-base font-medium"
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Create New Playbook
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Instances Library Card */}
            <Card className="bg-white border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-lg bg-[#0E7490] flex items-center justify-center">
                    <ListChecks className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-gray-900">My Instances</h2>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  View and manage all your completed workflow instances. Each instance contains AI-extracted answers based on your playbook questions.
                </p>
                
                <div className="space-y-3">
                  <Button
                    onClick={onNavigateToInstances}
                    className="w-full bg-[#0E7490] hover:bg-[#0c6380] text-white h-12 text-base font-medium"
                  >
                    <Eye className="w-5 h-5 mr-2" />
                    View Instances
                  </Button>
                  <Button
                    onClick={onNavigateToPlaybooks}
                    variant="outline"
                    className="w-full border-[#0E7490] text-[#0E7490] hover:bg-[#0E7490]/10 h-12 text-base font-medium"
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Use a Playbook
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* How It Works Section */}
          <div className="bg-white rounded-lg border border-gray-200 p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">How It Works</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Step 1 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  1
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Create a Playbook</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Define workflow phases, steps, and configure them for your process needs.
                </p>
              </div>

              {/* Step 2 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  2
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Use the Playbook</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Create an instance, assign owners, set due dates, and track progress through each step.
                </p>
              </div>

              {/* Step 3 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  3
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Track & Complete</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Monitor completion status, collaborate with team members, and manage multiple workflows.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}