import { ArrowLeft, Code, LayoutGrid, Save, X, CalendarIcon, GripVertical, ChevronDown, Plus, Pencil, Trash2, User, Copy } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useState, useRef } from 'react';
import { Card, CardContent } from './ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { format, parse } from 'date-fns';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';

interface InstanceEditorProps {
  instanceId: number;
  onBack: () => void;
}

// Mock instance data
const mockInstance = {
  id: 1,
  playbookName: 'Customer Onboarding',
  description: 'Standardize Customer Onboarding so every new employee gets a consistent onboarding experience.',
  dueDate: '2026-03-15',
  owners: ['Zakariya Jama', 'John Doe'],
  instanceDescription: 'Onboarding new customer Acme Corp.',
  phases: [
    {
      id: 1,
      name: 'Initial Setup',
      description: 'Initial phase to introduce the client and set expectations.',
      assignedTo: 'Zakariya Jama',
      startDate: '2026-03-01',
      endDate: '2026-03-05',
      relatedInfo: 'Customer contact: jane@acmecorp.com',
      steps: [
        {
          id: 1,
          name: 'Create account',
          description: 'Set up customer account in the system',
          assignedTo: 'Zakariya Jama',
          startDate: '2026-03-01',
          endDate: '2026-03-02',
          relatedInfo: 'Use standard account template',
          completed: true,
        },
        {
          id: 2,
          name: 'Send welcome email',
          description: 'Send automated welcome email to customer',
          assignedTo: 'Sarah Johnson',
          startDate: '2026-03-03',
          endDate: '2026-03-05',
          relatedInfo: 'Template ID: WEL-001',
          completed: false,
        },
      ],
    },
    {
      id: 2,
      name: 'Configuration',
      description: 'Setting up the client\'s access and workspace.',
      assignedTo: 'John Doe',
      startDate: '2026-03-06',
      endDate: '2026-03-10',
      relatedInfo: 'Workspace: acme-corp',
      steps: [
        {
          id: 1,
          name: 'Configure settings',
          description: 'Configure customer-specific settings',
          assignedTo: 'John Doe',
          startDate: '2026-03-06',
          endDate: '2026-03-08',
          relatedInfo: 'Settings doc: https://docs.example.com/config',
          completed: false,
        },
      ],
    },
  ],
};

const availableUsers = [
  'Zakariya Jama',
  'Sarah Johnson',
  'John Doe',
  'Emily Chen',
  'Michael Brown',
];

const ItemTypes = {
  PHASE: 'phase',
  STEP: 'step',
};

// Draggable Step Component
interface DraggableStepProps {
  step: any;
  stepIndex: number;
  phaseIndex: number;
  onUpdateStep: (phaseIndex: number, stepIndex: number, field: string, value: any) => void;
  onDeleteStep: (phaseIndex: number, stepIndex: number) => void;
  onMoveStep: (phaseIndex: number, fromIndex: number, toIndex: number) => void;
  onOpenConfig: (phaseIndex: number, stepIndex?: number) => void;
  isLast: boolean;
}

function DraggableStep({ step, stepIndex, phaseIndex, onUpdateStep, onDeleteStep, onMoveStep, onOpenConfig, isLast }: DraggableStepProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.STEP,
    item: { stepIndex, phaseIndex },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemTypes.STEP,
    hover: (item: { stepIndex: number; phaseIndex: number }) => {
      if (!ref.current) return;
      if (item.phaseIndex !== phaseIndex) return;
      if (item.stepIndex === stepIndex) return;

      onMoveStep(phaseIndex, item.stepIndex, stepIndex);
      item.stepIndex = stepIndex;
    },
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      className={`flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 transition-colors ${
        !isLast ? 'border-b border-gray-100' : ''
      } ${isDragging ? 'opacity-40' : 'opacity-100'}`}
    >
      {/* Teal square drag handle */}
      <div className="w-6 h-6 bg-[#006B7D] rounded flex items-center justify-center shrink-0 mt-0.5 cursor-grab active:cursor-grabbing">
        <GripVertical className="w-3.5 h-3.5 text-white" />
      </div>

      {/* Step name + description */}
      <div className="flex-1 min-w-0 space-y-1">
        <input
          value={step.name}
          onChange={(e) => onUpdateStep(phaseIndex, stepIndex, 'name', e.target.value)}
          className="w-full bg-transparent text-gray-900 font-medium outline-none border-b border-transparent hover:border-gray-300 focus:border-[#006B7D] transition-colors leading-tight"
          style={{ fontSize: '15px' }}
        />
        <input
          value={step.description}
          onChange={(e) => onUpdateStep(phaseIndex, stepIndex, 'description', e.target.value)}
          className="w-full bg-transparent text-gray-400 outline-none border-b border-transparent hover:border-gray-200 focus:border-gray-300 transition-colors"
          style={{ fontSize: '13px' }}
          placeholder="Step description..."
        />
      </div>

      {/* Edit step */}
      <button
        onClick={() => onOpenConfig(phaseIndex, stepIndex)}
        className="text-[#006B7D] hover:text-[#005568] p-0.5 shrink-0 mt-0.5 transition-colors"
        title="Edit step"
      >
        <Pencil className="w-4 h-4" />
      </button>

      {/* Red trash */}
      <button
        onClick={() => onDeleteStep(phaseIndex, stepIndex)}
        className="text-red-400 hover:text-red-600 p-0.5 shrink-0 mt-0.5 transition-colors"
        title="Delete step"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
}

// Draggable Phase Component
interface DraggablePhaseProps {
  phase: any;
  phaseIndex: number;
  onUpdatePhase: (phaseIndex: number, field: string, value: any) => void;
  onDeletePhase: (phaseIndex: number) => void;
  onMovePhase: (fromIndex: number, toIndex: number) => void;
  onAddStep: (phaseIndex: number) => void;
  onUpdateStep: (phaseIndex: number, stepIndex: number, field: string, value: any) => void;
  onDeleteStep: (phaseIndex: number, stepIndex: number) => void;
  onMoveStep: (phaseIndex: number, fromIndex: number, toIndex: number) => void;
  collapsed: boolean;
  onToggle: () => void;
  onOpenConfig: (phaseIndex: number, stepIndex?: number) => void;
}

function DraggablePhase({
  phase,
  phaseIndex,
  onUpdatePhase,
  onDeletePhase,
  onMovePhase,
  onAddStep,
  onUpdateStep,
  onDeleteStep,
  onMoveStep,
  collapsed,
  onToggle,
  onOpenConfig,
}: DraggablePhaseProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.PHASE,
    item: { phaseIndex },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemTypes.PHASE,
    hover: (item: { phaseIndex: number }) => {
      if (!ref.current) return;
      if (item.phaseIndex === phaseIndex) return;

      onMovePhase(item.phaseIndex, phaseIndex);
      item.phaseIndex = phaseIndex;
    },
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      className={`rounded-lg border border-[#C2CFC2] overflow-hidden ${isDragging ? 'opacity-40' : 'opacity-100'}`}
      style={{ backgroundColor: '#D8E4D8' }}
    >
      {/* Phase Header */}
      <div className="flex items-start gap-2 px-4 py-3">
        {/* Left controls */}
        <div className="text-[#006B7D] cursor-grab active:cursor-grabbing shrink-0 mt-1 opacity-70 hover:opacity-100">
          <GripVertical className="w-4 h-4" />
        </div>
        <button
          className="text-[#006B7D] shrink-0 mt-1 hover:opacity-70 transition-opacity"
          onClick={onToggle}
        >
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`}
          />
        </button>

        {/* Phase name + description + assignee */}
        <div className="flex-1 min-w-0 space-y-1">
          <input
            value={phase.name}
            onChange={(e) => onUpdatePhase(phaseIndex, 'name', e.target.value)}
            className="w-full bg-transparent text-[#006B7D] font-semibold outline-none border-b border-transparent hover:border-[#006B7D]/30 focus:border-[#006B7D] transition-colors leading-tight"
            style={{ fontSize: '17px' }}
          />
          <input
            value={(phase as any).description || ''}
            onChange={(e) => onUpdatePhase(phaseIndex, 'description', e.target.value)}
            className="w-full bg-transparent text-gray-500 outline-none border-b border-transparent hover:border-gray-300 focus:border-gray-400 transition-colors"
            style={{ fontSize: '14px' }}
            placeholder="Phase description..."
          />
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1.5 shrink-0 ml-2">
          <button
            onClick={() => onAddStep(phaseIndex)}
            className="w-7 h-7 bg-[#006B7D] rounded flex items-center justify-center text-white hover:bg-[#005568] transition-colors"
            title="Add step"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onOpenConfig(phaseIndex)}
            className="w-7 h-7 bg-[#006B7D] rounded flex items-center justify-center text-white hover:bg-[#005568] transition-colors"
            title="Edit phase"
          >
            <Pencil className="w-3 h-3" />
          </button>
          <button
            onClick={() => onDeletePhase(phaseIndex)}
            className="text-red-500 hover:text-red-600 p-1 transition-colors"
            title="Delete phase"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Steps */}
      {!collapsed && (
        <div className="mx-3 mb-3 rounded-lg overflow-hidden border border-gray-200 bg-white">
          {phase.steps.map((step: any, stepIndex: number) => (
            <DraggableStep
              key={step.id}
              step={step}
              stepIndex={stepIndex}
              phaseIndex={phaseIndex}
              onUpdateStep={onUpdateStep}
              onDeleteStep={onDeleteStep}
              onMoveStep={onMoveStep}
              onOpenConfig={onOpenConfig}
              isLast={stepIndex === phase.steps.length - 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function InstanceEditor({ instanceId, onBack }: InstanceEditorProps) {
  const [editorMode, setEditorMode] = useState<'ui' | 'json'>('ui');
  const [instanceData, setInstanceData] = useState(mockInstance);
  const [jsonData, setJsonData] = useState(JSON.stringify(mockInstance, null, 2));
  const [hasChanges, setHasChanges] = useState(false);
  const [newOwner, setNewOwner] = useState('');
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [collapsedPhases, setCollapsedPhases] = useState<Record<number, boolean>>({});
  
  // Configuration dialog state
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [configTarget, setConfigTarget] = useState<{ phaseIndex: number; stepIndex?: number } | null>(null);
  const [configStartCalendarOpen, setConfigStartCalendarOpen] = useState(false);
  const [configEndCalendarOpen, setConfigEndCalendarOpen] = useState(false);

  const handleCopyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(jsonData);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      alert('Failed to copy to clipboard');
    }
  };

  const togglePhase = (phaseIndex: number) => {
    setCollapsedPhases(prev => ({ ...prev, [phaseIndex]: !prev[phaseIndex] }));
  };

  const handleAddStep = (phaseIndex: number) => {
    const newPhases = [...instanceData.phases];
    const newStep = {
      id: Date.now(),
      name: 'New Step',
      description: 'Step description',
      assignedTo: '',
      startDate: '',
      endDate: '',
      relatedInfo: '',
      completed: false,
    };
    newPhases[phaseIndex].steps = [...newPhases[phaseIndex].steps, newStep];
    handleUpdateField('phases', newPhases);
  };

  const handleAddPhase = () => {
    const newPhase = {
      id: Date.now(),
      name: 'New Phase',
      description: 'Phase description',
      assignedTo: '',
      startDate: '',
      endDate: '',
      relatedInfo: '',
      steps: [],
    };
    handleUpdateField('phases', [...instanceData.phases, newPhase]);
  };

  const handleDeleteStep = (phaseIndex: number, stepIndex: number) => {
    const newPhases = [...instanceData.phases];
    newPhases[phaseIndex].steps = newPhases[phaseIndex].steps.filter((_, i) => i !== stepIndex);
    handleUpdateField('phases', newPhases);
  };

  const handleDeletePhase = (phaseIndex: number) => {
    const newPhases = instanceData.phases.filter((_, i) => i !== phaseIndex);
    handleUpdateField('phases', newPhases);
  };

  const handleMovePhase = (fromIndex: number, toIndex: number) => {
    const newPhases = [...instanceData.phases];
    const [movedPhase] = newPhases.splice(fromIndex, 1);
    newPhases.splice(toIndex, 0, movedPhase);
    handleUpdateField('phases', newPhases);
  };

  const handleMoveStep = (phaseIndex: number, fromIndex: number, toIndex: number) => {
    const newPhases = [...instanceData.phases];
    const steps = [...newPhases[phaseIndex].steps];
    const [movedStep] = steps.splice(fromIndex, 1);
    steps.splice(toIndex, 0, movedStep);
    newPhases[phaseIndex].steps = steps;
    handleUpdateField('phases', newPhases);
  };

  const handleSave = () => {
    if (editorMode === 'json') {
      try {
        const parsed = JSON.parse(jsonData);
        setInstanceData(parsed);
        setHasChanges(false);
        alert('Instance saved successfully!');
      } catch (error) {
        alert('Invalid JSON format. Please fix the errors and try again.');
      }
    } else {
      setJsonData(JSON.stringify(instanceData, null, 2));
      setHasChanges(false);
      alert('Instance saved successfully!');
    }
  };

  const handleUpdateField = (field: string, value: any) => {
    setInstanceData({ ...instanceData, [field]: value });
    setHasChanges(true);
  };

  const handleAddOwner = () => {
    if (newOwner.trim()) {
      handleUpdateField('owners', [...instanceData.owners, newOwner.trim()]);
      setNewOwner('');
    }
  };

  const handleRemoveOwner = (index: number) => {
    const newOwners = instanceData.owners.filter((_, i) => i !== index);
    handleUpdateField('owners', newOwners);
  };

  const handleUpdatePhase = (phaseIndex: number, field: string, value: any) => {
    const newPhases = [...instanceData.phases];
    newPhases[phaseIndex] = {
      ...newPhases[phaseIndex],
      [field]: value,
    };
    handleUpdateField('phases', newPhases);
  };

  const handleUpdateStep = (phaseIndex: number, stepIndex: number, field: string, value: any) => {
    const newPhases = [...instanceData.phases];
    newPhases[phaseIndex].steps[stepIndex] = {
      ...newPhases[phaseIndex].steps[stepIndex],
      [field]: value,
    };
    handleUpdateField('phases', newPhases);
  };

  const handleOpenConfig = (phaseIndex: number, stepIndex?: number) => {
    // Add logic to open configuration dialog for the phase or step
    setConfigTarget({ phaseIndex, stepIndex });
    setConfigDialogOpen(true);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-full flex flex-col bg-[#E8EDE8]">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-12 py-6">
          <button
            onClick={onBack}
            className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#006B7D] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
                Edit Instance
              </h1>
              <p className="text-gray-600 text-sm">
                {instanceData.playbookName}
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Advanced/JSON Editor Toggle */}
              <Button
                onClick={() => setEditorMode(editorMode === 'ui' ? 'json' : 'ui')}
                variant="outline"
                className="text-gray-600 border-gray-300 hover:border-[#006B7D] hover:text-[#006B7D]"
              >
                {editorMode === 'ui' ? (
                  <>
                    <Code className="w-4 h-4 mr-2" />
                    Advanced
                  </>
                ) : (
                  <>
                    <LayoutGrid className="w-4 h-4 mr-2" />
                    Visual Editor
                  </>
                )}
              </Button>
              <Button
                onClick={handleSave}
                className="bg-[#006B7D] hover:bg-[#005568] text-white px-6 gap-2"
              >
                <Save className="w-4 h-4" />
                Save Changes
                {hasChanges && <span className="ml-1 w-2 h-2 bg-amber-400 rounded-full"></span>}
              </Button>
            </div>
          </div>
        </div>

        {/* Editor Content */}
        <div className="flex-1 overflow-auto">
          {editorMode === 'ui' ? (
            // UI Editor
            <div className="max-w-[1400px] mx-auto px-12 py-8">
              <div className="grid grid-cols-1 lg:grid-cols-[minmax(300px,_2fr)_3fr] gap-6 items-start">
                {/* Left — Details */}
                <div>
                  <Card className="border-gray-200 sticky top-6">
                    <CardContent className="p-6">
                      <h2 className="text-lg font-semibold text-gray-900 mb-6">
                        Details
                      </h2>

                      <div className="grid grid-cols-[100px_1fr] gap-x-3 gap-y-4 items-center">

                        {/* Template */}
                        <Label htmlFor="playbookName" className="text-sm font-medium text-gray-700 text-right">
                          Template
                        </Label>
                        <div className="flex flex-wrap gap-1.5 px-3 py-2 border border-gray-200 rounded-md bg-gray-50 min-h-[38px] items-center">
                          <span className="text-sm text-gray-500">{instanceData.playbookName}</span>
                        </div>

                        {/* Due Date — Calendar Popover */}
                        <Label className="text-sm font-medium text-gray-700 text-right">
                          Due Date
                        </Label>
                        <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
                          <PopoverTrigger asChild>
                            <button
                              className="flex items-center gap-2 w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-900 hover:border-[#006B7D] focus:outline-none focus:ring-2 focus:ring-[#006B7D]/30 focus:border-[#006B7D] min-h-[38px] transition-colors text-left"
                            >
                              <CalendarIcon className="w-4 h-4 text-gray-400 shrink-0" />
                              {instanceData.dueDate
                                ? format(parse(instanceData.dueDate, 'yyyy-MM-dd', new Date()), 'MMMM d, yyyy')
                                : <span className="text-gray-400">Pick a date...</span>
                              }
                            </button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 z-50" align="start">
                            <Calendar
                              mode="single"
                              selected={instanceData.dueDate ? parse(instanceData.dueDate, 'yyyy-MM-dd', new Date()) : undefined}
                              onSelect={(date) => {
                                if (date) {
                                  handleUpdateField('dueDate', format(date, 'yyyy-MM-dd'));
                                }
                                setCalendarOpen(false);
                              }}
                              initialFocus
                              classNames={{
                                day_selected: 'bg-[#006B7D] text-white hover:bg-[#005568] hover:text-white focus:bg-[#006B7D] focus:text-white',
                                day_today: 'bg-[#006B7D]/10 text-[#006B7D]',
                              }}
                            />
                          </PopoverContent>
                        </Popover>

                        {/* Description */}
                        <Label htmlFor="instanceDescription" className="text-sm font-medium text-gray-700 text-right self-start mt-2">
                          Description
                        </Label>
                        <textarea
                          id="instanceDescription"
                          value={instanceData.instanceDescription}
                          onChange={(e) => handleUpdateField('instanceDescription', e.target.value)}
                          placeholder="Describe the purpose and context of this workflow instance..."
                          rows={2}
                          className="w-full resize-y px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-900 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-[#006B7D]/30 focus:border-[#006B7D] min-h-[38px] transition-colors"
                        />

                        {/* Owners */}
                        <Label className="text-sm font-medium text-gray-700 text-right self-start mt-2">
                          Owners
                        </Label>
                        <div
                          className="flex flex-wrap gap-1.5 px-3 py-2 border border-gray-300 rounded-md bg-white focus-within:ring-2 focus-within:ring-[#006B7D]/30 focus-within:border-[#006B7D] min-h-[38px] items-center cursor-text transition-colors"
                        >
                          {instanceData.owners.map((owner, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center gap-1 bg-[#006B7D]/10 text-[#006B7D] px-2 py-0.5 rounded-full text-sm shrink-0"
                            >
                              {owner}
                              <button
                                onClick={() => handleRemoveOwner(index)}
                                className="hover:bg-[#006B7D]/20 rounded-full p-0.5 ml-0.5"
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))}
                          <input
                            value={newOwner}
                            onChange={(e) => setNewOwner(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ',') {
                                e.preventDefault();
                                handleAddOwner();
                              }
                            }}
                            placeholder={instanceData.owners.length === 0 ? 'Add owners...' : ''}
                            className="flex-1 min-w-[80px] outline-none text-sm bg-transparent placeholder:text-gray-400"
                          />
                        </div>

                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Right — Phases and Steps */}
                <div>
                  <div className="space-y-4">
                    {instanceData.phases.map((phase, phaseIndex) => (
                      <DraggablePhase
                        key={phase.id}
                        phase={phase}
                        phaseIndex={phaseIndex}
                        onUpdatePhase={handleUpdatePhase}
                        onDeletePhase={handleDeletePhase}
                        onMovePhase={handleMovePhase}
                        onAddStep={handleAddStep}
                        onUpdateStep={handleUpdateStep}
                        onDeleteStep={handleDeleteStep}
                        onMoveStep={handleMoveStep}
                        collapsed={collapsedPhases[phaseIndex] || false}
                        onToggle={() => togglePhase(phaseIndex)}
                        onOpenConfig={handleOpenConfig}
                      />
                    ))}

                    {/* Add Phase Button */}
                    <Button
                      onClick={handleAddPhase}
                      variant="outline"
                      className="w-full border-2 border-dashed border-[#006B7D] text-[#006B7D] hover:bg-[#006B7D]/5 hover:text-[#005568] hover:border-[#005568] h-12"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Phase
                    </Button>
                  </div>
                </div>

              </div>
            </div>
          ) : (
            // JSON Editor
            <div className="h-full p-12">
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Code className="w-5 h-5 text-[#006B7D]" />
                  <h2 className="text-lg font-semibold text-gray-900">Advanced JSON Editor</h2>
                </div>
                <p className="text-sm text-gray-600">
                  Edit the raw JSON structure directly. Changes will be validated when you save.
                </p>
              </div>
              <div className="bg-gray-900 rounded-lg overflow-hidden" style={{ height: 'calc(100% - 120px)' }}>
                <Textarea
                  value={jsonData}
                  onChange={(e) => {
                    setJsonData(e.target.value);
                    setHasChanges(true);
                  }}
                  className="h-full font-mono text-sm bg-gray-900 text-green-400 border-0 resize-none rounded-lg p-4"
                  style={{ minHeight: '600px' }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Configuration Dialog */}
        <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-[#006B7D]">
                {configTarget && configTarget.stepIndex !== undefined 
                  ? `Configure Step: ${instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.name}` 
                  : `Configure Phase: ${instanceData.phases[configTarget?.phaseIndex || 0]?.name}`}
              </DialogTitle>
              <DialogDescription>
                Edit the configuration details for this {configTarget && configTarget.stepIndex !== undefined ? 'step' : 'phase'}.
              </DialogDescription>
            </DialogHeader>

            {configTarget && (
              <div className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-4">
                {/* Assigned To */}
                <Label className="text-sm font-medium text-gray-700 text-right self-center">
                  Assigned To
                </Label>
                <Select
                  value={
                    configTarget.stepIndex !== undefined
                      ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.assignedTo || ''
                      : instanceData.phases[configTarget.phaseIndex]?.assignedTo || ''
                  }
                  onValueChange={(value) => {
                    if (configTarget.stepIndex !== undefined) {
                      handleUpdateStep(configTarget.phaseIndex, configTarget.stepIndex, 'assignedTo', value);
                    } else {
                      handleUpdatePhase(configTarget.phaseIndex, 'assignedTo', value);
                    }
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select user..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableUsers.map((user) => (
                      <SelectItem key={user} value={user}>
                        {user}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Start Date */}
                <Label className="text-sm font-medium text-gray-700 text-right self-center">
                  Start Date
                </Label>
                <Popover open={configStartCalendarOpen} onOpenChange={setConfigStartCalendarOpen}>
                  <PopoverTrigger asChild>
                    <button
                      className="flex items-center gap-2 w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-900 hover:border-[#006B7D] focus:outline-none focus:ring-2 focus:ring-[#006B7D]/30 focus:border-[#006B7D] min-h-[38px] transition-colors text-left"
                    >
                      <CalendarIcon className="w-4 h-4 text-gray-400 shrink-0" />
                      {(configTarget.stepIndex !== undefined
                        ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.startDate
                        : instanceData.phases[configTarget.phaseIndex]?.startDate)
                        ? format(parse((configTarget.stepIndex !== undefined
                            ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.startDate
                            : instanceData.phases[configTarget.phaseIndex]?.startDate) || '', 'yyyy-MM-dd', new Date()), 'MMMM d, yyyy')
                        : <span className="text-gray-400">Pick a date...</span>
                      }
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={(configTarget.stepIndex !== undefined
                        ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.startDate
                        : instanceData.phases[configTarget.phaseIndex]?.startDate)
                        ? parse((configTarget.stepIndex !== undefined
                            ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.startDate
                            : instanceData.phases[configTarget.phaseIndex]?.startDate) || '', 'yyyy-MM-dd', new Date())
                        : undefined
                      }
                      onSelect={(date) => {
                        if (date) {
                          const formattedDate = format(date, 'yyyy-MM-dd');
                          if (configTarget.stepIndex !== undefined) {
                            handleUpdateStep(configTarget.phaseIndex, configTarget.stepIndex, 'startDate', formattedDate);
                          } else {
                            handleUpdatePhase(configTarget.phaseIndex, 'startDate', formattedDate);
                          }
                        }
                        setConfigStartCalendarOpen(false);
                      }}
                      initialFocus
                      classNames={{
                        day_selected: 'bg-[#006B7D] text-white hover:bg-[#005568] hover:text-white focus:bg-[#006B7D] focus:text-white',
                        day_today: 'bg-[#006B7D]/10 text-[#006B7D]',
                      }}
                    />
                  </PopoverContent>
                </Popover>

                {/* End Date */}
                <Label className="text-sm font-medium text-gray-700 text-right self-center">
                  End Date
                </Label>
                <Popover open={configEndCalendarOpen} onOpenChange={setConfigEndCalendarOpen}>
                  <PopoverTrigger asChild>
                    <button
                      className="flex items-center gap-2 w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-900 hover:border-[#006B7D] focus:outline-none focus:ring-2 focus:ring-[#006B7D]/30 focus:border-[#006B7D] min-h-[38px] transition-colors text-left"
                    >
                      <CalendarIcon className="w-4 h-4 text-gray-400 shrink-0" />
                      {(configTarget.stepIndex !== undefined
                        ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.endDate
                        : instanceData.phases[configTarget.phaseIndex]?.endDate)
                        ? format(parse((configTarget.stepIndex !== undefined
                            ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.endDate
                            : instanceData.phases[configTarget.phaseIndex]?.endDate) || '', 'yyyy-MM-dd', new Date()), 'MMMM d, yyyy')
                        : <span className="text-gray-400">Pick a date...</span>
                      }
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={(configTarget.stepIndex !== undefined
                        ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.endDate
                        : instanceData.phases[configTarget.phaseIndex]?.endDate)
                        ? parse((configTarget.stepIndex !== undefined
                            ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.endDate
                            : instanceData.phases[configTarget.phaseIndex]?.endDate) || '', 'yyyy-MM-dd', new Date())
                        : undefined
                      }
                      onSelect={(date) => {
                        if (date) {
                          const formattedDate = format(date, 'yyyy-MM-dd');
                          if (configTarget.stepIndex !== undefined) {
                            handleUpdateStep(configTarget.phaseIndex, configTarget.stepIndex, 'endDate', formattedDate);
                          } else {
                            handleUpdatePhase(configTarget.phaseIndex, 'endDate', formattedDate);
                          }
                        }
                        setConfigEndCalendarOpen(false);
                      }}
                      initialFocus
                      classNames={{
                        day_selected: 'bg-[#006B7D] text-white hover:bg-[#005568] hover:text-white focus:bg-[#006B7D] focus:text-white',
                        day_today: 'bg-[#006B7D]/10 text-[#006B7D]',
                      }}
                    />
                  </PopoverContent>
                </Popover>

                {/* Related Information */}
                <Label className="text-sm font-medium text-gray-700 text-right self-start mt-2">
                  Related Info
                </Label>
                <textarea
                  value={
                    configTarget.stepIndex !== undefined
                      ? instanceData.phases[configTarget.phaseIndex]?.steps[configTarget.stepIndex]?.relatedInfo || ''
                      : instanceData.phases[configTarget.phaseIndex]?.relatedInfo || ''
                  }
                  onChange={(e) => {
                    if (configTarget.stepIndex !== undefined) {
                      handleUpdateStep(configTarget.phaseIndex, configTarget.stepIndex, 'relatedInfo', e.target.value);
                    } else {
                      handleUpdatePhase(configTarget.phaseIndex, 'relatedInfo', e.target.value);
                    }
                  }}
                  placeholder="Add related information, links, or notes..."
                  rows={3}
                  className="w-full resize-y px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-900 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-[#006B7D]/30 focus:border-[#006B7D] min-h-[38px] transition-colors"
                />
              </div>
            )}

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setConfigDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => setConfigDialogOpen(false)}
                className="bg-[#006B7D] hover:bg-[#005568] text-white"
              >
                Save Configuration
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

      </div>
    </DndProvider>
  );
}