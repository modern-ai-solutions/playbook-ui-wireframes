import { useState } from 'react';
import { ArrowLeft, Plus, Trash2, MessageSquare, FileText, Sparkles, GripVertical, ChevronDown, Pencil } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent } from './ui/card';
import { Label } from './ui/label';

const TEAL = '#006B7D';
const TEAL_HOVER = '#005568';

interface CreateWorkflowProps {
  onBack: () => void;
}

interface Phase {
  id: string;
  name: string;
  description: string;
  steps: Step[];
}

interface Step {
  id: string;
  name: string;
  description: string;
}

export function CreateWorkflow({ onBack }: CreateWorkflowProps) {
  const [creationMethod, setCreationMethod] = useState<'choice' | 'wizard' | 'source'>('choice');
  const [wizardStep, setWizardStep] = useState<'name' | 'phases' | 'output'>('name');
  const [playbookName, setPlaybookName] = useState('');
  const [playbookDescription, setPlaybookDescription] = useState('');
  const [sourceText, setSourceText] = useState('');
  const [phases, setPhases] = useState<Phase[]>([]);
  const [selectedPhaseId, setSelectedPhaseId] = useState<string | null>(null);
  const [expandedPhases, setExpandedPhases] = useState<Set<string>>(new Set());
  const [draggedItem, setDraggedItem] = useState<{ type: 'phase' | 'step', phaseId: string, stepId?: string } | null>(null);

  const addPhase = () => {
    const newPhase: Phase = {
      id: Date.now().toString(),
      name: '',
      description: '',
      steps: [],
    };
    setPhases([...phases, newPhase]);
    setExpandedPhases(new Set([...expandedPhases, newPhase.id]));
  };

  const addStep = (phaseId: string, stepName?: string, stepDescription?: string) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        return {
          ...phase,
          steps: [
            ...phase.steps,
            {
              id: `${phaseId}-${Date.now()}`,
              name: stepName || '',
              description: stepDescription || '',
            },
          ],
        };
      }
      return phase;
    }));
    setExpandedPhases(new Set([...expandedPhases, phaseId]));
  };

  const removePhase = (phaseId: string) => {
    setPhases(phases.filter(phase => phase.id !== phaseId));
  };

  const removeStep = (phaseId: string, stepId: string) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        return {
          ...phase,
          steps: phase.steps.filter(step => step.id !== stepId),
        };
      }
      return phase;
    }));
  };

  const updatePhase = (phaseId: string, field: keyof Phase, value: string) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        return { ...phase, [field]: value };
      }
      return phase;
    }));
  };

  const updateStep = (phaseId: string, stepId: string, field: keyof Step, value: string) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        return {
          ...phase,
          steps: phase.steps.map(step => {
            if (step.id === stepId) {
              return { ...step, [field]: value };
            }
            return step;
          }),
        };
      }
      return phase;
    }));
  };

  const togglePhaseExpanded = (phaseId: string) => {
    const newExpanded = new Set(expandedPhases);
    if (newExpanded.has(phaseId)) {
      newExpanded.delete(phaseId);
    } else {
      newExpanded.add(phaseId);
    }
    setExpandedPhases(newExpanded);
  };

  const handleDragStart = (type: 'phase' | 'step', phaseId: string, stepId?: string) => {
    setDraggedItem({ type, phaseId, stepId });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent, targetPhaseId: string, targetStepId?: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!draggedItem) return;

    if (draggedItem.type === 'phase' && !targetStepId) {
      // Reorder phases
      const draggedIndex = phases.findIndex(p => p.id === draggedItem.phaseId);
      const targetIndex = phases.findIndex(p => p.id === targetPhaseId);
      
      if (draggedIndex !== -1 && targetIndex !== -1 && draggedIndex !== targetIndex) {
        const newPhases = [...phases];
        const [removed] = newPhases.splice(draggedIndex, 1);
        newPhases.splice(targetIndex, 0, removed);
        setPhases(newPhases);
      }
    } else if (draggedItem.type === 'step' && draggedItem.stepId && targetStepId) {
      // Reorder steps within the same phase
      if (draggedItem.phaseId === targetPhaseId) {
        setPhases(phases.map(phase => {
          if (phase.id === targetPhaseId) {
            const draggedStepIndex = phase.steps.findIndex(s => s.id === draggedItem.stepId);
            const targetStepIndex = phase.steps.findIndex(s => s.id === targetStepId);
            
            if (draggedStepIndex !== -1 && targetStepIndex !== -1 && draggedStepIndex !== targetStepIndex) {
              const newSteps = [...phase.steps];
              const [removed] = newSteps.splice(draggedStepIndex, 1);
              newSteps.splice(targetStepIndex, 0, removed);
              return { ...phase, steps: newSteps };
            }
          }
          return phase;
        }));
      }
    }

    setDraggedItem(null);
  };

  const handleGenerateDraft = () => {
    // Generate mock output for demonstration
    const draft: Phase[] = [];
    
    phases.forEach((phase) => {
      draft.push({
        ...phase,
        steps: phase.steps.length > 0 ? phase.steps : [],
      });
    });

    // Add sample phases if none exist
    if (draft.length === 0) {
      draft.push(
        {
          id: '1',
          name: 'Preparation Phase',
          description: 'Set up requirements and gather necessary information.',
          steps: [
            { id: '1-1', name: 'Collect requirements', description: 'Gather all necessary information and documents.' },
            { id: '1-2', name: 'Review prerequisites', description: 'Verify all prerequisites are met.' },
          ],
        },
        {
          id: '2',
          name: 'Execution Phase',
          description: 'Carry out the main workflow activities.',
          steps: [
            { id: '2-1', name: 'Start process', description: 'Begin the main workflow process.' },
            { id: '2-2', name: 'Monitor progress', description: 'Track and document progress.' },
          ],
        },
        {
          id: '3',
          name: 'Completion Phase',
          description: 'Finalize and document the results.',
          steps: [
            { id: '3-1', name: 'Review outcomes', description: 'Verify all tasks are completed successfully.' },
            { id: '3-2', name: 'Send notifications', description: 'Inform relevant parties of completion.' },
          ],
        }
      );
    }

    setPhases(draft);
    // Expand all phases in output view
    setExpandedPhases(new Set(draft.map(p => p.id)));
    setWizardStep('output');
  };

  // Calculate current step number for progress indicator
  const getCurrentStep = () => {
    if (creationMethod === 'choice') return 0;
    if (creationMethod === 'source') return 1;
    if (creationMethod === 'wizard') {
      if (wizardStep === 'name') return 1;
      if (wizardStep === 'phases') return 2;
      if (wizardStep === 'output') return 3;
    }
    return 0;
  };

  const currentStep = getCurrentStep();
  const totalSteps = creationMethod === 'wizard' ? 3 : creationMethod === 'source' ? 1 : 0;

  return (
    <div className="h-full flex flex-col bg-[#E8EDE8]">
      {/* Header */}
      <div className="bg-[#E8EDE8] px-12 py-6">
        <div className="flex items-center gap-3 mb-6">
          <Button 
            variant="ghost" 
            onClick={() => {
              if (creationMethod !== 'choice') {
                if (creationMethod === 'wizard' && wizardStep !== 'name') {
                  if (wizardStep === 'phases') setWizardStep('name');
                  else if (wizardStep === 'output') setWizardStep('phases');
                } else {
                  setCreationMethod('choice');
                  setWizardStep('name');
                }
              } else {
                onBack();
              }
            }}
            className="w-8 h-8 p-0 hover:bg-transparent"
            style={{ color: TEAL }}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 style={{ fontSize: '24px', fontWeight: 600, color: TEAL }}>
            Create New Playbook Template
          </h1>
        </div>
        
        {/* Progress Indicator - Centered */}
        {totalSteps > 0 && (
          <div className="flex justify-center mt-4">
            <div className="flex items-center gap-2">
              {Array.from({ length: totalSteps }).map((_, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold transition-colors"
                      style={{
                        backgroundColor: index + 1 <= currentStep ? TEAL : 'white',
                        color: index + 1 <= currentStep ? 'white' : '#9CA3AF',
                        border: index + 1 <= currentStep ? 'none' : '2px solid #D1D5DB'
                      }}
                    >
                      {index + 1}
                    </div>
                    <span className={`text-sm font-medium whitespace-nowrap ${
                      index + 1 <= currentStep ? 'text-gray-900' : 'text-gray-400'
                    }`}>
                      {creationMethod === 'wizard' && (
                        <>
                          {index === 0 && 'Playbook Details'}
                          {index === 1 && 'Build Structure'}
                          {index === 2 && 'Review & Save'}
                        </>
                      )}
                      {creationMethod === 'source' && 'Source Input'}
                    </span>
                  </div>
                  {index < totalSteps - 1 && (
                    <div 
                      className="h-0.5 w-16 mx-2"
                      style={{ backgroundColor: index + 1 < currentStep ? TEAL : '#D1D5DB' }}
                    ></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto px-12 py-8">
        {/* Choice Screen */}
        {creationMethod === 'choice' && (
          <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-10">
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">Choose Creation Method</h2>
              <p className="text-gray-600 mb-8">Select how you'd like to create your playbook template.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card
                  className="cursor-pointer transition-all hover:shadow-lg border-2 border-gray-200 bg-white"
                  style={{ borderColor: 'inherit' }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                  onClick={() => {
                    setCreationMethod('wizard');
                    setWizardStep('name');
                  }}
                >
                  <CardContent className="p-8">
                    <div className="w-16 h-16 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: TEAL }}>
                      <MessageSquare className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Wizard Chat</h3>
                    <p className="text-gray-600">
                      Use our step-by-step wizard to build your playbook with helpful prompts and suggestions.
                    </p>
                  </CardContent>
                </Card>

                <Card
                  className="cursor-pointer transition-all hover:shadow-lg border-2 border-gray-200 bg-white"
                  style={{ borderColor: 'inherit' }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                  onClick={() => setCreationMethod('source')}
                >
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-gray-600 to-gray-700 rounded-lg flex items-center justify-center mb-4">
                      <FileText className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Import from Text</h3>
                    <p className="text-gray-600">
                      Paste or type your playbook content directly as text or structured data.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}

        {/* Source Text Method */}
        {creationMethod === 'source' && (
          <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-10">
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">Import from Text</h2>
              <p className="text-gray-600 mb-8">Paste or type your playbook content below.</p>

              <div className="space-y-5">
                <div className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-4 items-center">
                  <Label htmlFor="playbook-name" className="text-sm font-semibold text-gray-700 text-right">
                    Playbook Name
                  </Label>
                  <Input
                    id="playbook-name"
                    placeholder="e.g., Employee Onboarding Process"
                    value={playbookName}
                    onChange={(e) => setPlaybookName(e.target.value)}
                    className="text-base bg-gray-100 border-gray-200"
                  />

                  <Label htmlFor="source-text" className="text-sm font-semibold text-gray-700 text-right self-start mt-2">
                    Content
                  </Label>
                  <Textarea
                    id="source-text"
                    placeholder="Paste your playbook content here..."
                    value={sourceText}
                    onChange={(e) => setSourceText(e.target.value)}
                    rows={15}
                    className="text-base bg-gray-100 border-gray-200 font-mono"
                  />
                </div>
              </div>

              <div className="mt-8 flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => setCreationMethod('choice')}
                >
                  Cancel
                </Button>
                <Button
                  onClick={onBack}
                  disabled={!playbookName || !sourceText}
                  className="text-white px-8"
                  style={{ backgroundColor: TEAL }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                >
                  Create Playbook
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Wizard Method - Step 1: Name & Description */}
        {creationMethod === 'wizard' && wizardStep === 'name' && (
          <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-10">
              <h2 className="text-2xl font-semibold text-gray-900 mb-3 text-center">Playbook Details</h2>
              <p className="text-gray-600 mb-8 text-center">Tell us about your playbook.</p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column - Form */}
                <div className="space-y-5">
                  <div className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-4 items-center">
                    <Label htmlFor="wizard-name" className="text-sm font-semibold text-gray-900 text-right">
                      Playbook Name
                    </Label>
                    <Input
                      id="wizard-name"
                      placeholder="e.g., New Employee Onboarding"
                      value={playbookName}
                      onChange={(e) => setPlaybookName(e.target.value)}
                      className="text-base bg-gray-100 border-gray-200"
                    />

                    <Label htmlFor="wizard-description" className="text-sm font-semibold text-gray-900 text-right self-start mt-2">
                      Purpose
                    </Label>
                    <Textarea
                      id="wizard-description"
                      placeholder="Describe the purpose and goals of this playbook..."
                      value={playbookDescription}
                      onChange={(e) => setPlaybookDescription(e.target.value)}
                      rows={5}
                      className="text-base bg-gray-100 border-gray-200"
                    />
                  </div>
                </div>

                {/* Right Column - AI Suggestions */}
                <div 
                  className="rounded-lg p-6 border"
                  style={{ 
                    background: `linear-gradient(to bottom right, ${TEAL}0D, #E8EDE8)`,
                    borderColor: `${TEAL}33`
                  }}
                >
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="w-5 h-5" style={{ color: TEAL }} />
                    <h3 className="font-semibold text-gray-900">Suggestions</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Not sure what to create? Try these examples:
                  </p>
                  <div className="space-y-3">
                    <button
                      onClick={() => {
                        setPlaybookName('Employee Onboarding');
                        setPlaybookDescription('Guide new hires through their first week with structured tasks and introductions.');
                      }}
                      className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                    >
                      <div className="font-medium text-gray-900 mb-1">Employee Onboarding</div>
                      <div className="text-xs text-gray-600">Welcome new team members</div>
                    </button>
                    <button
                      onClick={() => {
                        setPlaybookName('Customer Support Ticket');
                        setPlaybookDescription('Handle customer inquiries with clear escalation paths and response guidelines.');
                      }}
                      className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                    >
                      <div className="font-medium text-gray-900 mb-1">Customer Support</div>
                      <div className="text-xs text-gray-600">Resolve customer issues efficiently</div>
                    </button>
                    <button
                      onClick={() => {
                        setPlaybookName('Product Launch');
                        setPlaybookDescription('Coordinate teams and tasks for successful product releases with clear timelines.');
                      }}
                      className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                    >
                      <div className="font-medium text-gray-900 mb-1">Product Launch</div>
                      <div className="text-xs text-gray-600">Coordinate cross-team releases</div>
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex justify-center gap-3">
                <Button
                  variant="outline"
                  onClick={() => setCreationMethod('choice')}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => setWizardStep('phases')}
                  disabled={!playbookName || !playbookDescription}
                  className="text-white px-8"
                  style={{ backgroundColor: !playbookName || !playbookDescription ? '#9CA3AF' : TEAL }}
                  onMouseEnter={(e) => {
                    if (playbookName && playbookDescription) {
                      e.currentTarget.style.backgroundColor = TEAL_HOVER;
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (playbookName && playbookDescription) {
                      e.currentTarget.style.backgroundColor = TEAL;
                    }
                  }}
                >
                  Continue
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Wizard Method - Step 2: Add Phases and Steps */}
        {creationMethod === 'wizard' && wizardStep === 'phases' && (
          <div className="max-w-7xl mx-auto">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-10">
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">{playbookName}</h2>
              <p className="text-gray-600 mb-8">
                Build your playbook by adding phases and steps. Then generate your draft.
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Phase Builder (2/3 width) */}
                <div className="lg:col-span-2 space-y-4">
                  {phases.map((phase, phaseIndex) => (
                    <Card 
                      key={phase.id} 
                      className="border-2 bg-white cursor-pointer transition-all shadow-sm"
                      style={{
                        borderColor: selectedPhaseId === phase.id ? TEAL : '#D1D5DB',
                        backgroundColor: selectedPhaseId === phase.id ? '#F0F9FA' : 'white',
                        boxShadow: selectedPhaseId === phase.id ? '0 4px 6px -1px rgba(0, 107, 125, 0.1)' : ''
                      }}
                      onClick={() => setSelectedPhaseId(phase.id)}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-3 mb-4">
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-4 mb-3">
                              <Input
                                placeholder={`Phase ${phaseIndex + 1} Name`}
                                value={phase.name}
                                onChange={(e) => updatePhase(phase.id, 'name', e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                                className="font-semibold text-base bg-white border-2"
                                style={{ borderColor: '#D1D5DB' }}
                              />
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removePhase(phase.id);
                                }}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <Input
                              placeholder="Brief description of this phase"
                              value={phase.description}
                              onChange={(e) => updatePhase(phase.id, 'description', e.target.value)}
                              onClick={(e) => e.stopPropagation()}
                              className="text-sm bg-white border-2"
                              style={{ borderColor: '#D1D5DB' }}
                            />
                          </div>
                        </div>

                        {phase.steps.length > 0 && (
                          <div className="space-y-2 mb-3 ml-4">
                            {phase.steps.map((step, stepIndex) => (
                              <div 
                                key={step.id} 
                                className="flex items-start gap-3 rounded-lg p-3 border-2"
                                style={{ 
                                  backgroundColor: '#F9FAFB',
                                  borderColor: '#E5E7EB'
                                }}
                              >
                                <div 
                                  className="w-7 h-7 rounded-full text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                                  style={{ backgroundColor: TEAL }}
                                >
                                  {stepIndex + 1}
                                </div>
                                <div className="flex-1 space-y-2">
                                  <Input
                                    placeholder="Step name"
                                    value={step.name}
                                    onChange={(e) => updateStep(phase.id, step.id, 'name', e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                    className="text-sm bg-white border-2"
                                    style={{ borderColor: '#D1D5DB' }}
                                  />
                                  <Input
                                    placeholder="What needs to be done?"
                                    value={step.description}
                                    onChange={(e) => updateStep(phase.id, step.id, 'description', e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                    className="text-xs bg-white border-2"
                                    style={{ borderColor: '#D1D5DB' }}
                                  />
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeStep(phase.id, step.id);
                                  }}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50 mt-0.5"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            addStep(phase.id);
                          }}
                          className="w-full border-dashed border-2 border-gray-300 bg-white"
                          onMouseEnter={(e) => {
                            e.currentTarget.style.borderColor = TEAL;
                            e.currentTarget.style.backgroundColor = `${TEAL}0D`;
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.borderColor = '';
                            e.currentTarget.style.backgroundColor = 'white';
                          }}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Step to This Phase
                        </Button>
                      </CardContent>
                    </Card>
                  ))}

                  <Button
                    variant="outline"
                    onClick={addPhase}
                    className="w-full border-dashed border-2 border-gray-300 bg-white"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = TEAL;
                      e.currentTarget.style.backgroundColor = `${TEAL}0D`;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = '';
                      e.currentTarget.style.backgroundColor = 'white';
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Phase
                  </Button>
                </div>

                {/* Right Column - AI Suggestions (1/3 width) */}
                <div className="lg:col-span-1">
                  <div 
                    className="rounded-lg p-6 border sticky top-4"
                    style={{ 
                      background: `linear-gradient(to bottom right, ${TEAL}0D, #E8EDE8)`,
                      borderColor: `${TEAL}33`
                    }}
                  >
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="w-5 h-5" style={{ color: TEAL }} />
                      <h3 className="font-semibold text-gray-900">Suggestions</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">
                      Common phases to add:
                    </p>
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          const newPhase: Phase = {
                            id: Date.now().toString(),
                            name: 'Preparation',
                            description: 'Initial setup and planning',
                            steps: [],
                          };
                          setPhases([...phases, newPhase]);
                          setSelectedPhaseId(newPhase.id);
                        }}
                        className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                        onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                        onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                      >
                        <div className="font-medium text-gray-900 mb-1">+ Preparation</div>
                        <div className="text-xs text-gray-600">Setup and planning</div>
                      </button>
                      <button
                        onClick={() => {
                          const newPhase: Phase = {
                            id: Date.now().toString(),
                            name: 'Execution',
                            description: 'Main work activities',
                            steps: [],
                          };
                          setPhases([...phases, newPhase]);
                          setSelectedPhaseId(newPhase.id);
                        }}
                        className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                        onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                        onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                      >
                        <div className="font-medium text-gray-900 mb-1">+ Execution</div>
                        <div className="text-xs text-gray-600">Main work activities</div>
                      </button>
                      <button
                        onClick={() => {
                          const newPhase: Phase = {
                            id: Date.now().toString(),
                            name: 'Completion',
                            description: 'Final checks and closure',
                            steps: [],
                          };
                          setPhases([...phases, newPhase]);
                          setSelectedPhaseId(newPhase.id);
                        }}
                        className="w-full text-left p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-sm"
                        onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                        onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                      >
                        <div className="font-medium text-gray-900 mb-1">+ Completion</div>
                        <div className="text-xs text-gray-600">Final checks and closure</div>
                      </button>
                    </div>

                    {phases.length > 0 && (
                      <>
                        <div className="my-4 border-t border-gray-300"></div>
                        <p className="text-sm text-gray-600 mb-3">
                          {selectedPhaseId ? 'Common steps to add:' : 'Select a phase to add steps'}
                        </p>
                        {selectedPhaseId && (
                          <div className="space-y-2">
                            <button
                              onClick={() => addStep(selectedPhaseId, 'Send notification', 'Notify relevant people about this activity')}
                              className="w-full text-left p-2.5 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-xs"
                              onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                              onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                            >
                              <div className="font-medium text-gray-900">+ Send notification</div>
                            </button>
                            <button
                              onClick={() => addStep(selectedPhaseId, 'Collect feedback', 'Gather input from stakeholders')}
                              className="w-full text-left p-2.5 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-xs"
                              onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                              onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                            >
                              <div className="font-medium text-gray-900">+ Collect feedback</div>
                            </button>
                            <button
                              onClick={() => addStep(selectedPhaseId, 'Update records', 'Document changes in the system')}
                              className="w-full text-left p-2.5 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all text-xs"
                              onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                              onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                            >
                              <div className="font-medium text-gray-900">+ Update records</div>
                            </button>
                          </div>
                        )}
                      </>
                    )}

                    {/* Suggest More Button */}
                    <div className="mt-4">
                      <button
                        onClick={() => {
                          alert('More suggestions coming soon! This would connect to AI to generate more contextual suggestions based on your playbook.');
                        }}
                        className="w-full p-3 rounded-lg border-2 text-sm font-medium transition-all"
                        style={{ 
                          borderColor: TEAL,
                          color: TEAL,
                          backgroundColor: 'white'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = `${TEAL}0D`;
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = 'white';
                        }}
                      >
                        <div className="flex items-center justify-center gap-2">
                          <Sparkles className="w-4 h-4" />
                          Suggest More
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between gap-3 pt-6 mt-8 border-t border-gray-300">
                <Button
                  variant="outline"
                  onClick={() => setWizardStep('name')}
                >
                  Back
                </Button>
                <Button
                  onClick={handleGenerateDraft}
                  className="text-white px-8 gap-2"
                  style={{ background: `linear-gradient(to right, ${TEAL}, ${TEAL_HOVER})` }}
                  onMouseEnter={(e) => e.currentTarget.style.background = `linear-gradient(to right, ${TEAL_HOVER}, #004555)`}
                  onMouseLeave={(e) => e.currentTarget.style.background = `linear-gradient(to right, ${TEAL}, ${TEAL_HOVER})`}
                >
                  <Sparkles className="w-4 h-4" />
                  Generate Draft
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Wizard Method - Step 3: Output/Preview */}
        {creationMethod === 'wizard' && wizardStep === 'output' && (
          <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-10">
              <div className="flex items-start justify-between mb-6 pb-6 border-b border-gray-200">
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-2">{playbookName}</h2>
                  <p className="text-sm text-gray-600">{playbookDescription}</p>
                </div>
                <Button
                  onClick={addPhase}
                  className="text-white px-5 gap-2"
                  style={{ backgroundColor: TEAL }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                >
                  <Plus className="w-4 h-4" />
                  Add Phase
                </Button>
              </div>

              <div className="space-y-3">
                {phases.map((phase, phaseIndex) => (
                  <div 
                    key={phase.id} 
                    className="bg-white border border-gray-300 rounded-lg overflow-hidden transition-colors"
                    onMouseEnter={(e) => e.currentTarget.style.borderColor = TEAL}
                    onMouseLeave={(e) => e.currentTarget.style.borderColor = ''}
                    draggable
                    onDragStart={() => handleDragStart('phase', phase.id)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, phase.id)}
                  >
                    <div className="p-4 flex items-start gap-4">
                      {/* Icon Buttons */}
                      <div className="flex gap-2 flex-shrink-0">
                        <button 
                          className="w-8 h-8 text-white rounded flex items-center justify-center transition-colors cursor-move"
                          title="Drag to reorder"
                          style={{ backgroundColor: TEAL }}
                          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                        >
                          <GripVertical className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => togglePhaseExpanded(phase.id)}
                          className="w-8 h-8 text-white rounded flex items-center justify-center transition-colors"
                          title={expandedPhases.has(phase.id) ? "Collapse" : "Expand"}
                          style={{ backgroundColor: TEAL }}
                          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                        >
                          <ChevronDown className={`w-4 h-4 transition-transform ${expandedPhases.has(phase.id) ? '' : '-rotate-90'}`} />
                        </button>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 text-base mb-1">
                          {phase.name}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {phase.description}
                        </p>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-8 h-8 p-0"
                          onClick={() => addStep(phase.id)}
                          title="Add step"
                          style={{ color: TEAL }}
                          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = `${TEAL}1A`}
                          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = ''}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-8 h-8 p-0 text-gray-600 hover:bg-gray-100"
                          title="Edit phase"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-8 h-8 p-0 text-red-500 hover:bg-red-50 hover:text-red-600"
                          onClick={() => removePhase(phase.id)}
                          title="Delete phase"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Steps (if expanded and has steps) */}
                    {expandedPhases.has(phase.id) && phase.steps.length > 0 && (
                      <div className="border-t border-gray-200 bg-gray-50">
                        {phase.steps.map((step, stepIndex) => (
                          <div 
                            key={step.id} 
                            className="p-4 pl-20 flex items-start gap-4 border-b border-gray-200 last:border-b-0"
                            draggable
                            onDragStart={() => handleDragStart('step', phase.id, step.id)}
                            onDragOver={handleDragOver}
                            onDrop={(e) => handleDrop(e, phase.id, step.id)}
                          >
                            <div className="flex gap-2 flex-shrink-0">
                              <button 
                                className="w-8 h-8 text-white rounded flex items-center justify-center transition-colors cursor-move"
                                title="Drag to reorder"
                                style={{ backgroundColor: TEAL }}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                              >
                                <GripVertical className="w-4 h-4" />
                              </button>
                              <div 
                                className="w-8 h-8 rounded flex items-center justify-center font-semibold text-sm"
                                style={{ backgroundColor: TEAL, color: 'white' }}
                              >
                                {stepIndex + 1}
                              </div>
                            </div>

                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-gray-900 text-sm mb-1">
                                {step.name}
                              </h4>
                              <p className="text-xs text-gray-600">
                                {step.description}
                              </p>
                            </div>

                            <div className="flex gap-1 flex-shrink-0">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-8 h-8 p-0 text-gray-600 hover:bg-gray-100"
                                title="Edit step"
                              >
                                <Pencil className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-8 h-8 p-0 text-red-500 hover:bg-red-50 hover:text-red-600"
                                onClick={() => removeStep(phase.id, step.id)}
                                title="Delete step"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between gap-3 mt-8">
              <Button
                variant="outline"
                onClick={() => setWizardStep('phases')}
              >
                Back to Edit
              </Button>
              <Button
                onClick={onBack}
                className="text-white px-8"
                style={{ backgroundColor: TEAL }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = TEAL_HOVER}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
              >
                Save & Create Playbook
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}