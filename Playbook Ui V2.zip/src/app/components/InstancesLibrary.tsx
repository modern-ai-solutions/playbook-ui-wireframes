import { Search, Plus, Grid3x3, List, User, Calendar, CheckCircle2, FileCheck, Zap, Play, MoreVertical, Eye, Pencil, Trash2, Home, ArrowLeft, Download, Copy, Archive, FileJson, FileSpreadsheet, FileText } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from './ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { useState } from 'react';

interface InstancesLibraryProps {
  onCreateInstance: (playbookId: number) => void;
  onContinueInstance: (instanceId: number) => void;
  onEditInstance: (instanceId: number) => void;
  onBackHome?: () => void;
}

const instances = [
  {
    id: 1,
    playbookId: 1,
    playbookName: 'Customer Onboarding',
    description: 'Standardize Customer Onboarding so every new employee gets a consistent onboarding experience.',
    owner: 'Zakariya Jama',
    timesUsed: 0,
    created: '03/02/2026',
    dueDate: '03/15/2026',
    status: 'active',
    progress: 0,
    totalSteps: 12,
    completedSteps: 0,
  },
  {
    id: 2,
    playbookId: 2,
    playbookName: 'Incident Response',
    description: 'Define a clear Incident Response',
    owner: 'Dominic Avellani',
    timesUsed: 2,
    created: '02/26/2026',
    dueDate: '03/10/2026',
    status: 'active',
    progress: 35,
    totalSteps: 15,
    completedSteps: 5,
  },
  {
    id: 3,
    playbookId: 3,
    playbookName: 'Customer Onboarding - Example',
    description: 'Guide the client from kickoff to successful handoff with clear ownership and',
    owner: 'Dominic Avellani',
    timesUsed: 0,
    created: '02/26/2026',
    dueDate: '03/20/2026',
    status: 'active',
    progress: 0,
    totalSteps: 8,
    completedSteps: 0,
  },
  {
    id: 4,
    playbookId: 1,
    playbookName: 'New Employee Onboarding',
    description: 'Run New Employee Onboarding so every new employee gets a consistent onboarding experience.',
    owner: 'Sarah Johnson',
    timesUsed: 3,
    created: '02/20/2026',
    dueDate: '03/05/2026',
    status: 'active',
    progress: 75,
    totalSteps: 20,
    completedSteps: 15,
  },
];

export function InstancesLibrary({ onCreateInstance, onContinueInstance, onEditInstance, onBackHome }: InstancesLibraryProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [instanceToDelete, setInstanceToDelete] = useState<number | null>(null);

  const handleExportJSON = (instance: any) => {
    const dataStr = JSON.stringify(instance, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `${instance.playbookName.replace(/\s+/g, '_')}_${instance.id}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleExportCSV = (instance: any) => {
    const csvContent = [
      ['Field', 'Value'],
      ['Instance ID', instance.id],
      ['Playbook Name', instance.playbookName],
      ['Description', instance.description],
      ['Owner', instance.owner],
      ['Created', instance.created],
      ['Due Date', instance.dueDate],
      ['Status', instance.status],
      ['Progress', `${instance.progress}%`],
      ['Completed Steps', instance.completedSteps],
      ['Total Steps', instance.totalSteps],
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    
    const dataUri = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
    const exportFileDefaultName = `${instance.playbookName.replace(/\s+/g, '_')}_${instance.id}.csv`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleExportTXT = (instance: any) => {
    const txtContent = `
Instance Report
===============

Instance ID: ${instance.id}
Playbook Name: ${instance.playbookName}
Description: ${instance.description}

Details:
--------
Owner: ${instance.owner}
Created: ${instance.created}
Due Date: ${instance.dueDate}
Status: ${instance.status}

Progress:
---------
${instance.completedSteps} of ${instance.totalSteps} steps completed (${instance.progress}%)
    `.trim();
    
    const dataUri = 'data:text/plain;charset=utf-8,' + encodeURIComponent(txtContent);
    const exportFileDefaultName = `${instance.playbookName.replace(/\s+/g, '_')}_${instance.id}.txt`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleDeleteClick = (instanceId: number) => {
    setInstanceToDelete(instanceId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (instanceToDelete) {
      // Perform delete operation here
      console.log('Deleting instance:', instanceToDelete);
      alert(`Instance ${instanceToDelete} deleted successfully!`);
      setDeleteDialogOpen(false);
      setInstanceToDelete(null);
    }
  };

  const getStatusBadge = (status: string) => {
    if (status === 'active') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
          <CheckCircle2 className="w-3 h-3" />
          Active
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
        <FileCheck className="w-3 h-3" />
        Draft
      </span>
    );
  };

  const getProgressBar = (progress: number) => {
    return (
      <div className="w-full">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-gray-600">Progress</span>
          <span className="text-xs font-medium text-gray-900">{progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-[#006B7D] h-2 rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col overflow-auto">
      {/* Header */}
      <div className="px-12 pt-12 pb-8">
        <div className="mb-6">
          {onBackHome && (
            <button
              onClick={onBackHome}
              className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          )}
          <div>
            <h1 className="text-[#0E7490] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
              My Instances
            </h1>
            <p className="text-gray-600 text-sm">Track and manage your active playbook instances</p>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="px-12 pb-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search instances..."
                className="pl-10 bg-gray-50 border-gray-200 text-sm"
              />
            </div>

            <div className="flex items-center gap-3 ml-auto">
              {/* Status Filter */}
              <Select defaultValue="active">
                <SelectTrigger className="w-32 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>

              {/* Sort */}
              <Select defaultValue="duedate">
                <SelectTrigger className="w-40 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="duedate">Due Date</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="progress">Progress</SelectItem>
                </SelectContent>
              </Select>

              {/* View Toggle */}
              <div className="flex items-center gap-0 bg-gray-100 rounded p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'grid' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'list' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-12 pb-12">
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {instances.map((instance) => (
              <Card 
                key={instance.id} 
                className="bg-white border-gray-200 hover:shadow-lg transition-all relative group"
              >
                <CardContent className="p-6">
                  {/* 3-dot Menu */}
                  <div className="absolute top-4 right-4 z-10">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="h-8 w-8 flex items-center justify-center rounded-md text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuSub>
                          <DropdownMenuSubTrigger className="gap-2 cursor-pointer">
                            <Download className="w-4 h-4 text-gray-500" />
                            Export
                          </DropdownMenuSubTrigger>
                          <DropdownMenuSubContent>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportJSON(instance)}
                            >
                              <FileJson className="w-4 h-4 text-gray-500" />
                              JSON File
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportCSV(instance)}
                            >
                              <FileSpreadsheet className="w-4 h-4 text-gray-500" />
                              CSV File
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportTXT(instance)}
                            >
                              <FileText className="w-4 h-4 text-gray-500" />
                              Text File
                            </DropdownMenuItem>
                          </DropdownMenuSubContent>
                        </DropdownMenuSub>
                        <DropdownMenuItem className="gap-2 cursor-pointer">
                          <Copy className="w-4 h-4 text-gray-500" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2 cursor-pointer">
                          <Archive className="w-4 h-4 text-gray-500" />
                          Archive
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          className="gap-2 cursor-pointer text-red-600 focus:text-red-600"
                          onClick={() => handleDeleteClick(instance.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Title and Description */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 pr-10">
                    {instance.playbookName}
                  </h3>
                  <p className="text-sm text-gray-600 mb-6 leading-relaxed line-clamp-2">
                    {instance.description}
                  </p>

                  {/* Progress Bar */}
                  <div className="mb-6">
                    {getProgressBar(instance.progress)}
                    <p className="text-xs text-gray-500 mt-1">
                      {instance.completedSteps} of {instance.totalSteps} steps completed
                    </p>
                  </div>

                  {/* Metadata with Icons */}
                  <div className="space-y-2.5 mb-6 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900 font-medium">{instance.owner}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Due: <span className="text-gray-900 font-medium">{instance.dueDate}</span></span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 text-white text-sm h-10 font-medium"
                      style={{ backgroundColor: '#006B7D' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#006B7D'}
                      onClick={() => onContinueInstance(instance.id)}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Continue
                    </Button>
                    <Button 
                      variant="outline"
                      className="px-3 h-10 border-gray-300 hover:bg-gray-50"
                      onClick={() => onEditInstance(instance.id)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {viewMode === 'list' && (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Instance Name</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Owner</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Progress</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Due Date</th>
                  <th className="text-right px-6 py-2.5 text-sm font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {instances.map((instance) => (
                  <tr key={instance.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3">
                      <div>
                        <span className="font-semibold text-gray-900 text-sm">{instance.playbookName}</span>
                        <p className="text-xs text-gray-500 line-clamp-1">{instance.description}</p>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-sm text-gray-700">{instance.owner}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="w-40">
                        {getProgressBar(instance.progress)}
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-sm text-gray-600">{instance.dueDate}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-[#006B7D] hover:bg-[#006B7D]/10 h-8 px-3"
                          onClick={() => onContinueInstance(instance.id)}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Continue
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-gray-700 hover:bg-gray-100 h-8 px-3"
                          onClick={() => onEditInstance(instance.id)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-gray-400 hover:text-gray-700 hover:bg-gray-100">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuSub>
                              <DropdownMenuSubTrigger className="gap-2 cursor-pointer">
                                <Download className="w-4 h-4 text-gray-500" />
                                Export
                              </DropdownMenuSubTrigger>
                              <DropdownMenuSubContent>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportJSON(instance)}
                                >
                                  <FileJson className="w-4 h-4 text-gray-500" />
                                  JSON File
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportCSV(instance)}
                                >
                                  <FileSpreadsheet className="w-4 h-4 text-gray-500" />
                                  CSV File
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportTXT(instance)}
                                >
                                  <FileText className="w-4 h-4 text-gray-500" />
                                  Text File
                                </DropdownMenuItem>
                              </DropdownMenuSubContent>
                            </DropdownMenuSub>
                            <DropdownMenuItem className="gap-2 cursor-pointer">
                              <Copy className="w-4 h-4 text-gray-500" />
                              Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuItem className="gap-2 cursor-pointer">
                              <Archive className="w-4 h-4 text-gray-500" />
                              Archive
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer text-red-600 focus:text-red-600"
                              onClick={() => handleDeleteClick(instance.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the instance.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}