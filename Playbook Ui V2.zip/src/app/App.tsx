import { useState } from 'react';
import { Homepage } from './components/Homepage';
import { ProjectsOverview } from './components/ProjectsOverview';
import { CreateWorkflow } from './components/CreateWorkflow';
import { ViewPlaybook } from './components/ViewPlaybook';
import { InstancesLibrary } from './components/InstancesLibrary';
import { InstanceChecklist } from './components/InstanceChecklist';
import { InstanceEditor } from './components/InstanceEditor';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'overview' | 'create' | 'view' | 'instances' | 'instanceChecklist' | 'instanceEditor'>('home');
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | null>(null);
  const [selectedInstanceId, setSelectedInstanceId] = useState<number | null>(null);

  const handleViewPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('view');
  };

  const handleInstanceCreated = () => {
    setCurrentView('instances');
  };

  const handleContinueInstance = (instanceId: number) => {
    setSelectedInstanceId(instanceId);
    setCurrentView('instanceChecklist');
  };

  const handleEditInstance = (instanceId: number) => {
    setSelectedInstanceId(instanceId);
    setCurrentView('instanceEditor');
  };

  return (
    <div className="size-full bg-[#E8EDE8]">
      {currentView === 'home' && (
        <Homepage 
          onNavigateToPlaybooks={() => setCurrentView('overview')}
          onNavigateToInstances={() => setCurrentView('instances')}
          onCreatePlaybook={() => setCurrentView('create')}
        />
      )}
      {currentView === 'overview' && (
        <ProjectsOverview 
          onCreateNew={() => setCurrentView('create')} 
          onViewPlaybook={handleViewPlaybook}
          onInstanceCreated={handleInstanceCreated}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'create' && <CreateWorkflow onBack={() => setCurrentView('home')} />}
      {currentView === 'view' && selectedPlaybookId && (
        <ViewPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
        />
      )}
      {currentView === 'instances' && (
        <InstancesLibrary
          onCreateInstance={(playbookId) => {
            setSelectedPlaybookId(playbookId);
            setCurrentView('overview');
          }}
          onContinueInstance={handleContinueInstance}
          onEditInstance={handleEditInstance}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'instanceChecklist' && selectedInstanceId && (
        <InstanceChecklist
          instanceId={selectedInstanceId}
          onBack={() => setCurrentView('instances')}
        />
      )}
      {currentView === 'instanceEditor' && selectedInstanceId && (
        <InstanceEditor
          instanceId={selectedInstanceId}
          onBack={() => setCurrentView('instances')}
        />
      )}
    </div>
  );
}