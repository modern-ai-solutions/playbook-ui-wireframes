import { useState } from 'react';
import { Homepage } from './components/Homepage';
import { ProjectsOverview } from './components/ProjectsOverview';
import { CreateWorkflow } from './components/CreateWorkflow';
import { ViewPlaybook } from './components/ViewPlaybook';
import { InstancesLibrary } from './components/InstancesLibrary';
import { InstanceChecklist } from './components/InstanceChecklist';
import { EditPlaybook } from './components/EditPlaybook';
import { ViewRelatedInstances } from './components/ViewRelatedInstances';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'overview' | 'create' | 'view' | 'instances' | 'instanceChecklist' | 'editPlaybook' | 'viewRelated'>('home');
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | null>(null);
  const [selectedInstanceId, setSelectedInstanceId] = useState<number | null>(null);
  const [createOrigin, setCreateOrigin] = useState<'home' | 'overview'>('home');

  const handleViewPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('view');
  };

  const handleEditPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('editPlaybook');
  };

  const handleViewRelated = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('viewRelated');
  };

  const handleInstanceCreated = (instanceId?: number) => {
    if (instanceId) {
      setSelectedInstanceId(instanceId);
      setCurrentView('instanceChecklist');
    } else {
      setCurrentView('instances');
    }
  };

  const handleContinueInstance = (instanceId: number) => {
    setSelectedInstanceId(instanceId);
    setCurrentView('instanceChecklist');
  };

  return (
    <div className="size-full bg-[#E8EDE8]">
      {currentView === 'home' && (
        <Homepage 
          onNavigateToPlaybooks={() => setCurrentView('overview')}
          onNavigateToInstances={() => setCurrentView('instances')}
          onCreatePlaybook={() => { setCreateOrigin('home'); setCurrentView('create'); }}
        />
      )}
      {currentView === 'overview' && (
        <ProjectsOverview 
          onCreateNew={() => { setCreateOrigin('overview'); setCurrentView('create'); }} 
          onViewPlaybook={handleViewPlaybook}
          onEditPlaybook={handleEditPlaybook}
          onViewRelated={handleViewRelated}
          onInstanceCreated={handleInstanceCreated}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'create' && (
        <CreateWorkflow
          onBack={() => setCurrentView(createOrigin)}
          onSave={() => setCurrentView('overview')}
        />
      )}
      {currentView === 'view' && selectedPlaybookId && (
        <ViewPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')}
          onUsePlaybook={(playbookId) => {
            setSelectedInstanceId(playbookId);
            setCurrentView('instanceChecklist');
          }}
        />
      )}
      {currentView === 'editPlaybook' && selectedPlaybookId && (
        <EditPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
          onSave={() => setCurrentView('overview')}
        />
      )}
      {currentView === 'viewRelated' && selectedPlaybookId && (
        <ViewRelatedInstances 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
        />
      )}
      {currentView === 'instances' && (
        <InstancesLibrary
          onCreateInstance={(playbookId) => {
            setSelectedPlaybookId(playbookId);
            setCurrentView('overview');
          }}
          onContinueInstance={handleContinueInstance}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'instanceChecklist' && selectedInstanceId && (
        <InstanceChecklist
          instanceId={selectedInstanceId}
          onBack={() => setCurrentView('instances')}
        />
      )}
      <Toaster position="bottom-right" />
    </div>
  );
}