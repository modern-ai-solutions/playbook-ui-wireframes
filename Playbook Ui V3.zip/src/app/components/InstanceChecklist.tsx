import { ArrowLeft, ChevronDown, Send, Edit2, Check, Plus, Pencil, Trash2, GripVertical, CheckCircle2, User, Bell, Braces, Copy } from 'lucide-react';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { useState } from 'react';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from './ui/sheet';

interface InstanceChecklistProps {
  instanceId: number;
  onBack: () => void;
}

// Mock data for the instance
const instanceData = {
  id: 1,
  name: 'Customer Onboarding - Acme Corp',
  playbookName: 'Customer Onboarding Playbook',
  owner: 'Zakariya Jama',
  dueDate: '03/15/2026',
  created: '03/02/2026',
  status: 'in-progress' as 'to-do' | 'in-progress' | 'done' | 'rejected',
  description: 'Onboarding workflow for new customer Acme Corp. Includes account setup, configuration, training, and handoff.',
  phases: [
    {
      id: 1,
      name: 'Initial Setup',
      assignedTo: 'Zakariya Jama',
      isExpanded: true,
      isCompleted: true,
      steps: [
        {
          id: 1,
          name: 'Create customer account',
          description: 'Set up the customer account in the system with all necessary access permissions and initial configuration.',
          isCompleted: true,
          assignedTo: 'Zakariya Jama',
        },
        {
          id: 2,
          name: 'Send welcome email',
          description: 'Send automated welcome email to customer with login credentials and getting started guide.',
          isCompleted: true,
          assignedTo: 'Sarah Johnson',
        },
      ],
    },
    {
      id: 2,
      name: 'Configuration',
      assignedTo: 'John Doe',
      isExpanded: true,
      isCompleted: false,
      steps: [
        {
          id: 1,
          name: 'Configure system settings',
          description: 'Configure customer-specific settings including branding, user roles, and integration preferences.',
          isCompleted: false,
          assignedTo: 'Zakariya Jama',
        },
        {
          id: 2,
          name: 'Set up integrations',
          description: 'Connect required third-party integrations and test data flow.',
          isCompleted: false,
          assignedTo: 'John Doe',
        },
      ],
    },
    {
      id: 3,
      name: 'Training & Handoff',
      assignedTo: '',
      isExpanded: false,
      isCompleted: false,
      steps: [
        {
          id: 1,
          name: 'Conduct training session',
          description: 'Schedule and deliver comprehensive training session for customer team.',
          isCompleted: false,
          assignedTo: 'Sarah Johnson',
        },
        {
          id: 2,
          name: 'Complete handoff documentation',
          description: 'Prepare and deliver all handoff documentation including setup details and support contacts.',
          isCompleted: false,
          assignedTo: '',
        },
      ],
    },
  ],
};

const availableUsers = [
  'Zakariya Jama',
  'Sarah Johnson',
  'John Doe',
  'Emily Chen',
  'Michael Brown',
];

const activityHistory = [
  {
    id: 1,
    user: 'Zakariya Jama',
    action: 'completed step',
    target: 'Create customer account',
    timestamp: '3/9/26 - 2:30 PM',
    timeAgo: '4 days ago',
    type: 'activity',
  },
  {
    id: 2,
    user: 'Sarah Johnson',
    action: 'completed step',
    target: 'Send welcome email',
    timestamp: '3/9/26 - 3:45 PM',
    timeAgo: '4 days ago',
    type: 'activity',
  },
  {
    id: 3,
    user: 'Zakariya Jama',
    action: 'assigned',
    target: 'Configure system settings',
    assignee: 'Zakariya Jama',
    timestamp: '3/10/26 - 9:15 AM',
    timeAgo: '3 days ago',
    type: 'activity',
  },
  {
    id: 4,
    user: 'John Doe',
    action: 'commented',
    target: 'Set up integrations',
    comment: 'Working on connecting the CRM system. Should be done by end of day.',
    timestamp: '3/10/26 - 10:30 AM',
    timeAgo: '3 days ago',
    type: 'comment',
  },
  {
    id: 5,
    user: 'Sarah Johnson',
    action: 'commented',
    target: 'Training session',
    comment: 'Planning to schedule this for next week. Will send out calendar invites.',
    timestamp: '3/11/26 - 11:20 AM',
    timeAgo: '2 days ago',
    type: 'comment',
  },
  {
    id: 6,
    user: 'Zakariya Jama',
    action: 'started working on',
    target: 'Configure system settings',
    timestamp: '3/12/26 - 9:00 AM',
    timeAgo: '1 day ago',
    type: 'activity',
  },
];

export function InstanceChecklist({ instanceId, onBack }: InstanceChecklistProps) {
  const [phases, setPhases] = useState(instanceData.phases);
  const [comment, setComment] = useState('');
  const [editingPhaseId, setEditingPhaseId] = useState<number | null>(null);
  const [editingStepId, setEditingStepId] = useState<{ phaseId: number; stepId: number } | null>(null);
  const [instanceStatus, setInstanceStatus] = useState<'to-do' | 'in-progress' | 'done' | 'rejected'>(instanceData.status);
  const [editingStatus, setEditingStatus] = useState(false);
  const [notifMessage, setNotifMessage] = useState('');
  const [notifSubject, setNotifSubject] = useState('');
  const [notifRecipient, setNotifRecipient] = useState('all');
  const [sentNotifs, setSentNotifs] = useState<{ id: number; type: string; recipient: string; time: string }[]>([]);
  const [jsonDrawerOpen, setJsonDrawerOpen] = useState(false);
  const [jsonCopied, setJsonCopied] = useState(false);

  const allSteps = phases.flatMap(phase => phase.steps);
  const completedSteps = allSteps.filter(step => step.isCompleted).length;
  const totalSteps = allSteps.length;
  const progressPercentage = Math.round((completedSteps / totalSteps) * 100);

  const togglePhase = (phaseId: number) => {
    setPhases(phases.map(phase => 
      phase.id === phaseId 
        ? { ...phase, isExpanded: !phase.isExpanded }
        : phase
    ));
  };

  const togglePhaseComplete = (phaseId: number) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        const newCompleted = !phase.isCompleted;
        return {
          ...phase,
          isCompleted: newCompleted,
          steps: phase.steps.map(step => ({ ...step, isCompleted: newCompleted }))
        };
      }
      return phase;
    }));
  };

  const toggleStepComplete = (phaseId: number, stepId: number) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        const newSteps = phase.steps.map(step =>
          step.id === stepId ? { ...step, isCompleted: !step.isCompleted } : step
        );
        return {
          ...phase,
          steps: newSteps,
          isCompleted: newSteps.every(s => s.isCompleted)
        };
      }
      return phase;
    }));
  };

  const assignPhase = (phaseId: number, user: string) => {
    setPhases(phases.map(phase =>
      phase.id === phaseId ? { ...phase, assignedTo: user } : phase
    ));
    setEditingPhaseId(null); // Close edit mode after assignment
  };

  const assignStep = (phaseId: number, stepId: number, user: string) => {
    setPhases(phases.map(phase => {
      if (phase.id === phaseId) {
        return {
          ...phase,
          steps: phase.steps.map(step =>
            step.id === stepId ? { ...step, assignedTo: user } : step
          ),
        };
      }
      return phase;
    }));
    setEditingStepId(null); // Close edit mode after assignment
  };

  const handleAddComment = () => {
    if (comment.trim()) {
      console.log('Comment added:', comment);
      // In real app, this would add to activity history
      setComment('');
    }
  };

  const instanceJson = JSON.stringify(
    { ...instanceData, phases, status: instanceStatus },
    null,
    2
  );

  const handleCopyJson = () => {
    navigator.clipboard.writeText(instanceJson);
    setJsonCopied(true);
    setTimeout(() => setJsonCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-[#E8EDE8]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-12 py-6">
        <button
          onClick={onBack}
          className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Library
        </button>
        
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-[#006B7D] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
              {instanceData.name}
            </h1>
            <p className="text-gray-600 text-sm max-w-3xl">
              {instanceData.description}
            </p>
          </div>
          {/* Option 2: Header JSON button */}
          <button
            onClick={() => setJsonDrawerOpen(true)}
            title="View JSON"
            className="flex items-center gap-1.5 px-3 py-2 rounded-md border border-gray-200 text-gray-500 hover:text-[#006B7D] hover:border-[#006B7D] hover:bg-[#006B7D]/5 transition-colors text-sm shrink-0 mt-1"
          >
            <Braces className="w-4 h-4" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-[1600px] mx-auto px-12 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-6 gap-6">
            {/* Left Sidebar - Instance Info */}
            <div className="lg:col-span-1">
              {/* Instance Details Card */}
              <div className="bg-white border border-gray-200 rounded-lg p-6 sticky top-6">
                <h3 className="font-semibold text-gray-900 mb-5 text-base">Details</h3>
                
                {/* Metadata */}
                <div className="space-y-3">
                  {/* Status */}
                  <div className="text-sm flex items-center gap-2">
                    <span className="text-gray-600 shrink-0">Status:</span>
                    {editingStatus ? (
                      <Select
                        value={instanceStatus}
                        onValueChange={(value: 'to-do' | 'in-progress' | 'done' | 'rejected') => {
                          setInstanceStatus(value);
                          setEditingStatus(false);
                        }}
                        open={true}
                        onOpenChange={(open) => { if (!open) setEditingStatus(false); }}
                      >
                        <SelectTrigger className="w-full h-8 text-sm bg-white border-[#006B7D]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="to-do">To Do</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="done">Done</SelectItem>
                          <SelectItem value="rejected">Rejected</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <button
                        onClick={() => setEditingStatus(true)}
                        className="flex items-center gap-1.5 group"
                      >
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${
                          instanceStatus === 'to-do'
                            ? 'bg-gray-100 text-gray-600 border-gray-200'
                            : instanceStatus === 'in-progress'
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : instanceStatus === 'done'
                            ? 'bg-green-50 text-green-700 border-green-200'
                            : 'bg-red-50 text-red-600 border-red-200'
                        }`}>
                          {instanceStatus === 'to-do' ? 'To Do'
                            : instanceStatus === 'in-progress' ? 'In Progress'
                            : instanceStatus === 'done' ? 'Done'
                            : 'Rejected'}
                        </span>
                        <Edit2 className="w-3 h-3 text-gray-400 opacity-0 group-hover:opacity-100 group-hover:text-[#006B7D] transition-opacity" />
                      </button>
                    )}
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Owner:</span>{' '}
                    <span className="font-medium text-gray-900">{instanceData.owner}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Due Date:</span>{' '}
                    <span className="font-medium text-gray-900">{instanceData.dueDate}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Created:</span>{' '}
                    <span className="font-medium text-gray-900">{instanceData.created}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Centre - Workflow Steps */}
            <div className="lg:col-span-3">
              <div className="space-y-4 mb-8">
                {phases.map((phase) => (
                  <div key={phase.id} className="rounded-xl border border-gray-200 overflow-hidden bg-[#f0f4f0]">
                    
                    {/* ── Phase Header ── */}
                    <div className="flex items-center justify-between px-4 py-3.5">
                      {/* Left: collapse toggle + title */}
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <button
                          onClick={() => togglePhase(phase.id)}
                          className="w-7 h-7 rounded-md flex items-center justify-center text-white shrink-0"
                          style={{ backgroundColor: '#006B7D' }}
                        >
                          <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${phase.isExpanded ? '' : '-rotate-90'}`} />
                        </button>
                        {/* Phase title + description */}
                        <div className="ml-2 min-w-0">
                          <p className="font-semibold text-[#006B7D] text-base leading-tight">{phase.name}</p>
                          <p className="text-sm text-gray-500 mt-0.5 truncate">
                            {phase.steps.filter(s => s.isCompleted).length} of {phase.steps.length} steps completed
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* ── Steps ── */}
                    {phase.isExpanded && (
                      <div className="mx-3 mb-3 rounded-lg overflow-hidden border border-gray-200 bg-white">
                        {phase.steps.map((step, stepIdx) => (
                          <div
                            key={step.id}
                            className={`flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors ${
                              stepIdx < phase.steps.length - 1 ? 'border-b border-gray-100' : ''
                            }`}
                          >
                            {/* Checkbox */}
                            <Checkbox
                              checked={step.isCompleted}
                              onCheckedChange={() => toggleStepComplete(phase.id, step.id)}
                              className="shrink-0"
                            />

                            {/* Step name + description */}
                            <div className="flex-1 min-w-0">
                              <p className={`text-base font-semibold leading-snug ${step.isCompleted ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                                {step.name}
                              </p>
                              <p className="text-sm text-gray-500 mt-0.5 leading-snug">{step.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Right Panel - Activity & Comments */}
            <div className="lg:col-span-2">
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden sticky top-6">
                <Tabs defaultValue="all" className="w-full">
                  <div className="border-b border-gray-200 bg-gray-50/50">
                    <TabsList className="w-full justify-start h-auto p-0 bg-transparent rounded-none flex flex-wrap">
                      <TabsTrigger
                        value="all"
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#006B7D] data-[state=active]:bg-white data-[state=active]:shadow-sm px-4 py-3 text-sm font-medium"
                      >
                        All Activities
                      </TabsTrigger>
                      <TabsTrigger
                        value="comments"
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#006B7D] data-[state=active]:bg-white data-[state=active]:shadow-sm px-4 py-3 text-sm font-medium"
                      >
                        Comments
                      </TabsTrigger>
                      <TabsTrigger
                        value="history"
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#006B7D] data-[state=active]:bg-white data-[state=active]:shadow-sm px-4 py-3 text-sm font-medium"
                      >
                        History
                      </TabsTrigger>
                      <TabsTrigger
                        value="notifications"
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#006B7D] data-[state=active]:bg-white data-[state=active]:shadow-sm px-4 py-3 text-sm font-medium"
                      >
                        Messages
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  {/* All Activities Tab */}
                  <TabsContent value="all" className="m-0 p-5 max-h-[70vh] overflow-y-auto">
                    <div className="space-y-5">
                      {activityHistory.map((activity) => (
                        <div key={activity.id} className="flex gap-2.5">
                          <div className="flex-shrink-0">
                            <div className="w-8 h-8 rounded-full bg-[#006B7D] flex items-center justify-center text-white text-xs font-medium">
                              {activity.user.split(' ').map(n => n[0]).join('')}
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm mb-1">
                              <span className="font-semibold text-gray-900">{activity.user}</span>
                              {' '}
                              <span className="text-gray-600">{activity.action}</span>
                              {' '}
                              <span className="text-[#006B7D] font-medium">{activity.target}</span>
                              {activity.assignee && activity.assignee !== activity.target && (
                                <>
                                  {' '}
                                  <span className="text-gray-600">to</span>
                                  {' '}
                                  <span className="text-gray-900 font-medium">{activity.assignee}</span>
                                </>
                              )}
                            </div>
                            {activity.comment && (
                              <div className="text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded-lg p-2.5">
                                {activity.comment}
                              </div>
                            )}
                            <div className="text-xs text-gray-400 mt-1">{activity.timeAgo}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  {/* Comments Tab */}
                  <TabsContent value="comments" className="m-0 p-5 max-h-[70vh] overflow-y-auto">
                    <div className="space-y-5">
                      {activityHistory
                        .filter(activity => activity.type === 'comment')
                        .map((activity) => (
                          <div key={activity.id} className="flex gap-2.5">
                            <div className="flex-shrink-0">
                              <div className="w-8 h-8 rounded-full bg-[#006B7D] flex items-center justify-center text-white text-xs font-medium">
                                {activity.user.split(' ').map(n => n[0]).join('')}
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm mb-1.5">
                                <span className="font-semibold text-gray-900">{activity.user}</span>
                                <span className="text-xs text-gray-400 ml-2">{activity.timeAgo}</span>
                              </div>
                              {activity.comment && (
                                <div className="text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded-lg p-2.5">
                                  {activity.comment}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}

                      {activityHistory.filter(a => a.type === 'comment').length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-8">No comments yet.</p>
                      )}

                      {/* Add Comment */}
                      <div className="pt-4 border-t border-gray-200">
                        <div className="relative">
                          <Textarea
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            placeholder="Share your thoughts or ask a question..."
                            className="min-h-[90px] text-sm pr-11 border-gray-300 focus:border-[#006B7D] focus:ring-[#006B7D] resize-none bg-white"
                          />
                          <Button
                            onClick={handleAddComment}
                            size="icon"
                            className="absolute bottom-2.5 right-2.5 bg-[#006B7D] hover:bg-[#005568] text-white h-8 w-8 rounded-full shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled={!comment.trim()}
                          >
                            <Send className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  {/* History Tab */}
                  <TabsContent value="history" className="m-0 p-5 max-h-[70vh] overflow-y-auto">
                    <div className="space-y-5">
                      {activityHistory
                        .filter(activity => activity.type === 'activity')
                        .map((activity) => (
                          <div key={activity.id} className="flex gap-2.5">
                            <div className="flex-shrink-0">
                              <div className="w-8 h-8 rounded-full bg-[#006B7D] flex items-center justify-center text-white text-xs font-medium">
                                {activity.user.split(' ').map(n => n[0]).join('')}
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm mb-1">
                                <span className="font-semibold text-gray-900">{activity.user}</span>
                                {' '}
                                <span className="text-gray-600">{activity.action}</span>
                                {' '}
                                <span className="text-[#006B7D] font-medium">{activity.target}</span>
                                {activity.assignee && activity.assignee !== activity.target && (
                                  <>
                                    {' '}
                                    <span className="text-gray-600">to</span>
                                    {' '}
                                    <span className="text-gray-900 font-medium">{activity.assignee}</span>
                                  </>
                                )}
                              </div>
                              <div className="text-xs text-gray-400 mt-1">{activity.timeAgo}</div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </TabsContent>

                  {/* Messages Tab */}
                  <TabsContent value="notifications" className="m-0 p-5 max-h-[70vh] overflow-y-auto">
                    <div className="space-y-4">

                      {/* Send to */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Send to:</label>
                        <Select value={notifRecipient} onValueChange={setNotifRecipient}>
                          <SelectTrigger className="w-full bg-white text-sm">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Everyone assigned to this instance</SelectItem>
                            <SelectItem value="Zakariya Jama">Zakariya Jama</SelectItem>
                            <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                            <SelectItem value="John Doe">John Doe</SelectItem>
                            <SelectItem value="Emily Chen">Emily Chen</SelectItem>
                            <SelectItem value="Michael Brown">Michael Brown</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Message Subject */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Message Subject:</label>
                        <Input
                          value={notifSubject}
                          onChange={(e) => setNotifSubject(e.target.value)}
                          placeholder="e.g. Action required: please update your steps"
                          className="bg-white text-sm border-gray-300 focus:border-[#006B7D] focus:ring-[#006B7D]"
                        />
                      </div>

                      {/* Message Body */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Message Body:</label>
                        <div className="relative">
                          <Textarea
                            value={notifMessage}
                            onChange={(e) => setNotifMessage(e.target.value)}
                            placeholder="e.g. Please check your assigned steps and update progress by end of day."
                            className="min-h-[90px] text-sm pr-11 border-gray-300 focus:border-[#006B7D] focus:ring-[#006B7D] resize-none bg-white"
                          />
                          <Button
                            onClick={() => {
                              if (notifMessage.trim()) {
                                setNotifMessage('');
                                setNotifSubject('');
                              }
                            }}
                            size="icon"
                            className="absolute bottom-2.5 right-2.5 bg-[#006B7D] hover:bg-[#005568] text-white h-8 w-8 rounded-full shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled={!notifMessage.trim()}
                          >
                            <Send className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                        <p className="text-xs text-gray-400 mt-1.5">Recipients will receive an email with your message.</p>
                      </div>

                      {/* Quick presets */}
                      <div>
                        <p className="text-xs text-gray-500 mb-2">Ready-made messages:</p>
                        <div className="flex flex-col gap-1.5">
                          {[
                            'Please review your steps and mark any completed ones as done.',
                            'Friendly reminder — this instance is approaching its due date.',
                            'Could you share a quick update on where things stand?',
                            'Great progress! Please check your remaining steps when you get a chance.',
                          ].map((preset) => (
                            <button
                              key={preset}
                              onClick={() => setNotifMessage(preset)}
                              className="text-left text-xs text-gray-600 px-3 py-2 rounded-md border border-gray-200 bg-gray-50 hover:bg-gray-100 hover:border-gray-300 transition-colors"
                            >
                              {preset}
                            </button>
                          ))}
                        </div>
                      </div>

                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Option 2: JSON Drawer (Sheet) */}
      <Sheet open={jsonDrawerOpen} onOpenChange={setJsonDrawerOpen}>
        <SheetContent side="right" className="w-[480px] sm:w-[540px] flex flex-col p-0">
          <SheetHeader className="px-6 py-5 border-b border-gray-200">
            <SheetTitle className="flex items-center gap-2 text-[#006B7D]">
              <Braces className="w-5 h-5" />
              Instance JSON
            </SheetTitle>
          </SheetHeader>
          <div className="flex-1 overflow-auto px-6 py-5">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs text-gray-500">Read-only snapshot of this instance's current state.</p>
              <button
                onClick={handleCopyJson}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded border border-gray-200 text-gray-500 hover:text-[#006B7D] hover:border-[#006B7D] transition-colors"
              >
                {jsonCopied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                {jsonCopied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <pre className="text-xs leading-relaxed text-gray-700 bg-gray-50 border border-gray-200 rounded-lg p-4 overflow-auto font-mono whitespace-pre">
              {instanceJson}
            </pre>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}