import { ArrowLeft, Calendar, User, CheckCircle2, Clock, XCircle, AlertCircle, Play, Edit, Pencil, Grid3x3, List, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { useState } from 'react';

interface ViewRelatedInstancesProps {
  playbookId: number;
  onBack: () => void;
}

// Mock data for instances related to a playbook
const mockRelatedInstances: Record<number, any> = {
  1: {
    playbookName: 'New Employee Onboarding',
    instances: [
      {
        id: 1,
        name: 'Onboard John Smith - Engineering',
        owner: 'Sarah Johnson',
        status: 'in-progress',
        dueDate: '2026-03-25',
        created: '2026-03-10',
        progress: 60,
        completedSteps: 9,
        totalSteps: 15,
      },
      {
        id: 2,
        name: 'Onboard Emily Davis - Marketing',
        owner: 'Michael Brown',
        status: 'done',
        created: '2026-03-05',
        progress: 100,
        completedSteps: 15,
        totalSteps: 15,
      },
      {
        id: 3,
        name: 'Onboard Alex Chen - Sales',
        owner: 'Sarah Johnson',
        status: 'to-do',
        dueDate: '2026-04-01',
        created: '2026-03-15',
        progress: 0,
        completedSteps: 0,
        totalSteps: 15,
      },
      {
        id: 4,
        name: 'Onboard Maria Garcia - HR',
        owner: 'John Doe',
        status: 'in-progress',
        created: '2026-03-12',
        progress: 45,
        completedSteps: 7,
        totalSteps: 15,
      },
      {
        id: 5,
        name: 'Onboard David Wilson - Product',
        owner: 'Emily Chen',
        status: 'done',
        dueDate: '2026-03-18',
        created: '2026-03-01',
        progress: 100,
        completedSteps: 15,
        totalSteps: 15,
      },
      {
        id: 6,
        name: 'Onboard Lisa Anderson - Design',
        owner: 'Michael Brown',
        status: 'rejected',
        created: '2026-03-08',
        progress: 30,
        completedSteps: 5,
        totalSteps: 15,
      },
    ],
  },
  2: {
    playbookName: 'Client Welcome Process',
    instances: [
      {
        id: 7,
        name: 'Welcome Acme Corp',
        owner: 'Sarah Johnson',
        status: 'in-progress',
        dueDate: '2026-03-30',
        created: '2026-03-15',
        progress: 40,
        completedSteps: 4,
        totalSteps: 10,
      },
      {
        id: 8,
        name: 'Welcome TechStart Inc',
        owner: 'John Doe',
        status: 'done',
        created: '2026-03-10',
        progress: 100,
        completedSteps: 10,
        totalSteps: 10,
      },
    ],
  },
};

export function ViewRelatedInstances({ playbookId, onBack }: ViewRelatedInstancesProps) {
  const data = mockRelatedInstances[playbookId] || mockRelatedInstances[1];
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const getStatusBadge = (status: string) => {
    const configs = {
      'to-do': {
        bg: 'bg-gray-100',
        text: 'text-gray-600',
        icon: Clock,
        label: 'To Do',
      },
      'in-progress': {
        bg: 'bg-blue-100',
        text: 'text-blue-700',
        icon: AlertCircle,
        label: 'In Progress',
      },
      'done': {
        bg: 'bg-green-100',
        text: 'text-green-700',
        icon: CheckCircle2,
        label: 'Done',
      },
      'rejected': {
        bg: 'bg-red-100',
        text: 'text-red-600',
        icon: XCircle,
        label: 'Rejected',
      },
    };

    const config = configs[status as keyof typeof configs] || configs['to-do'];
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon className="w-3 h-3" />
        {config.label}
      </span>
    );
  };

  const getProgressBar = (progress: number) => {
    return (
      <div className="w-full">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-gray-600">Progress</span>
          <span className="text-xs font-medium text-gray-900">{progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-[#006B7D] h-2 rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col bg-[#E8EDE8] overflow-auto">
      {/* Header */}
      <div className="px-12 pt-12 pb-8">
        <div className="mb-6">
          <button
            onClick={onBack}
            className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Playbooks Library
          </button>
          <div>
            <h1 className="text-[#0E7490] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
              Related Instances
            </h1>
            <p className="text-gray-600 text-sm">
              Instances created from "{data.playbookName}" • {data.instances.length} total
            </p>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="px-12 pb-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search instances..."
                className="pl-10 bg-gray-50 border-gray-200 text-sm"
              />
            </div>

            <div className="flex items-center gap-3 ml-auto">
              {/* Status Filter */}
              <Select defaultValue="all">
                <SelectTrigger className="w-36 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="to-do">To Do</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>

              {/* Sort */}
              <Select defaultValue="newest">
                <SelectTrigger className="w-40 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="duedate">Due Date</SelectItem>
                  <SelectItem value="progress">Progress</SelectItem>
                </SelectContent>
              </Select>

              {/* View Toggle */}
              <div className="flex items-center gap-0 bg-gray-100 rounded p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'grid' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'list' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-12 pb-12">
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.instances.map((instance: any) => (
              <Card 
                key={instance.id} 
                className="bg-white border-gray-200 hover:shadow-lg transition-all relative group"
              >
                <CardContent className="p-6">
                  {/* Title */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 pr-10">
                    {instance.name}
                  </h3>

                  {/* Progress Bar */}
                  <div className="mb-6">
                    {getProgressBar(instance.progress)}
                    <p className="text-xs text-gray-500 mt-1">
                      {instance.completedSteps} of {instance.totalSteps} steps completed
                    </p>
                  </div>

                  {/* Metadata */}
                  <div className="space-y-2.5 mb-6 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900 font-medium">{instance.owner}</span>
                    </div>
                    {instance.dueDate && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span>Due: <span className="text-gray-900 font-medium">{instance.dueDate}</span></span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 text-white text-sm h-10 font-medium"
                      style={{ backgroundColor: '#006B7D' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#006B7D'}
                      onClick={() => console.log('Continue instance', instance.id)}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Continue
                    </Button>
                    <Button 
                      variant="outline"
                      className="px-3 h-10 border-gray-300 hover:bg-gray-50"
                      onClick={() => console.log('Edit instance', instance.id)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {viewMode === 'list' && (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Instance Name</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Owner</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Progress</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Due Date</th>
                  <th className="text-right px-6 py-2.5 text-sm font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.instances.map((instance: any) => (
                  <tr key={instance.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3">
                      <span className="font-semibold text-gray-900 text-sm">{instance.name}</span>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-sm text-gray-700">{instance.owner}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="w-40">
                        {getProgressBar(instance.progress)}
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      {instance.dueDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-sm text-gray-600">{instance.dueDate}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-[#006B7D] hover:bg-[#006B7D]/10 h-8 px-3"
                          onClick={() => console.log('Continue instance', instance.id)}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Continue
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-gray-700 hover:bg-gray-100 h-8 px-3"
                          onClick={() => console.log('Edit instance', instance.id)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}