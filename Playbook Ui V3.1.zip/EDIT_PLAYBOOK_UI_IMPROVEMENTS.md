# UI/UX Improvements for Playbook Library Edit Functionality

## Current State Analysis

The current edit functionality includes:
- **EditPlaybook component**: Full-featured drag-and-drop editor with phases and steps
- **Access points**: 
  - From ViewPlaybook page ("Edit Template" button)
  - From Playbooks Library (3-dot menu → Edit action - if implemented)
- **Features**: Inline editing, drag-and-drop reordering, add/delete phases/steps, export options

---

## 🎯 Recommended UI/UX Improvements

### 1. **Quick Edit vs. Full Edit Modes**

#### Problem
Users might want to make small changes (like fixing a typo) without entering the full editor experience.

#### Solution: Add "Quick Edit" Inline Mode
- **Quick Edit** (in Playbooks Library grid/list view):
  - Double-click playbook name/description to edit inline
  - Save/Cancel buttons appear on hover
  - No page navigation required
  - Perfect for: Title changes, description updates, owner changes

- **Full Edit** (current EditPlaybook component):
  - Navigate to dedicated editor page
  - Full workflow editing with drag-and-drop
  - Perfect for: Restructuring phases, reordering steps, major changes

**Implementation:**
```tsx
// In ProjectsOverview card
<div 
  onDoubleClick={() => setQuickEditMode(playbook.id)}
  className="cursor-text"
>
  {quickEditMode === playbook.id ? (
    <input 
      value={editedTitle}
      onChange={...}
      onBlur={handleSaveQuickEdit}
      autoFocus
      className="inline-edit-field"
    />
  ) : (
    <h3>{playbook.title}</h3>
  )}
</div>
```

---

### 2. **Visual Feedback for Unsaved Changes**

#### Problem
Users might accidentally navigate away without saving changes.

#### Solution: Enhanced Change Tracking
- **Header indicator**: Show orange dot next to "Save Changes" button (✓ Already implemented)
- **Add browser confirmation**: Prompt when leaving page with unsaved changes
- **Auto-save draft**: Save changes to localStorage every 30 seconds
- **Last saved timestamp**: Display "Last saved at 2:45 PM" below header

**Implementation:**
```tsx
// Add beforeunload listener
useEffect(() => {
  const handleBeforeUnload = (e: BeforeUnloadEvent) => {
    if (hasChanges) {
      e.preventDefault();
      e.returnValue = '';
    }
  };
  window.addEventListener('beforeunload', handleBeforeUnload);
  return () => window.removeEventListener('beforeunload', handleBeforeUnload);
}, [hasChanges]);

// Auto-save to localStorage
useEffect(() => {
  if (hasChanges) {
    const timer = setTimeout(() => {
      localStorage.setItem(`playbook-draft-${playbookId}`, JSON.stringify(playbookData));
      setLastSaved(new Date());
    }, 30000);
    return () => clearTimeout(timer);
  }
}, [hasChanges, playbookData]);
```

---

### 3. **Version History & Restore**

#### Problem
No way to undo major changes or see what was changed previously.

#### Solution: Add Version History
- **Version sidebar**: Collapsible panel showing previous versions
- **Timestamp + author**: Who made changes and when
- **Diff view**: Show what changed between versions
- **One-click restore**: Revert to previous version with confirmation

**UI Design:**
```
┌─────────────────────────────────────────┐
│ Edit Playbook               [History ▼] │
├─────────────────────────────────────────┤
│                              ┌──────────┤
│ [Playbook Details]           │ Versions │
│                              │──────────│
│ [Phase 1]                    │ ● Today  │
│   - Step 1                   │   2:30 PM│
│   - Step 2                   │   by You │
│                              │          │
│ [Phase 2]                    │ ○ Mar 17 │
│   - Step 3                   │   4:15 PM│
│                              │   by John│
│                              │          │
│                              │ ○ Mar 15 │
│                              │   10:00AM│
│                              └──────────┘
```

---

### 4. **Bulk Actions for Steps/Phases**

#### Problem
Managing many steps/phases one at a time is tedious.

#### Solution: Add Multi-Select & Bulk Operations
- **Checkbox mode**: Toggle to show checkboxes next to all items
- **Select all**: Quick select within a phase or entire playbook
- **Bulk actions**:
  - Move selected items to different phase
  - Delete multiple steps at once
  - Duplicate selected steps
  - Apply tags/metadata to multiple items

**UI Design:**
```
[Bulk Edit Mode ON]  3 items selected
[Move to...] [Delete] [Duplicate] [Cancel]

□ Phase 1: Pre-Arrival Setup
  ☑ Create Email Account
  ☑ Order Equipment  
  □ Prepare Workspace
```

---

### 5. **Smart Templates & Suggestions**

#### Problem
Users start from scratch when creating similar phases/steps.

#### Solution: Add Template Library
- **Phase templates**: Pre-built phase structures
  - "Standard Onboarding Checklist"
  - "Security Review Process"
  - "Client Handoff Steps"
  
- **Smart suggestions**: Based on playbook category/title
  - "Other playbooks in 'Onboarding' category include these phases:"
  - Click to add entire phase with steps

- **Recent patterns**: Show user's frequently used structures

**UI Design:**
```
┌────────────────────────────────┐
│ Add Phase                      │
├────────────────────────────────┤
│ Create Custom Phase            │
│ ──────────────────────────────│
│ 📋 Use Template:               │
│   • IT Setup (3 steps)         │
│   • Compliance Training (5)    │
│   • Benefits Enrollment (4)    │
│ ──────────────────────────────│
│ 💡 From Similar Playbooks:     │
│   • First Week Orientation     │
│   • Manager Introduction       │
└────────────────────────────────┘
```

---

### 6. **Collaborative Editing Features**

#### Problem
Multiple users might edit the same playbook simultaneously.

#### Solution: Add Real-Time Collaboration
- **Who's viewing**: Show avatars of current viewers
- **Lock sections**: Prevent conflicts by locking edited sections
- **Comments & suggestions**: Add inline comments like Google Docs
- **Request review**: Send playbook to another user for feedback

**UI Design:**
```
┌─────────────────────────────────────────┐
│ Edit Playbook    👤DA 👤MJ (viewing)   │
│                                         │
│ Phase 1: Pre-Arrival Setup   💬 2       │
│   [Sarah commented: "Add background     │
│    check step before email creation"]  │
│   ✓ Create Email Account               │
│   ⚠️ Order Equipment [MJ is editing]   │
└─────────────────────────────────────────┘
```

---

### 7. **Rich Text Editing for Descriptions**

#### Problem
Plain text descriptions limit formatting and clarity.

#### Solution: Add Formatting Options
- **Basic formatting**: Bold, italic, bullet points, numbered lists
- **Hyperlinks**: Link to documentation, resources
- **Mentions**: @mention users for assignments
- **Markdown support**: For technical users

**UI Design:**
```
Step Description:
┌────────────────────────────────────┐
│ [B] [I] [•] [1.] [🔗] [@]         │
├────────────────────────────────────┤
│ Set up company email and grant     │
│ necessary permissions:             │
│                                    │
│ • Access to Slack workspace        │
│ • Calendar permissions             │
│ • See: https://docs.company.com/it │
│                                    │
│ Assign to: @ITAdmin                │
└────────────────────────────────────┘
```

---

### 8. **Improved Visual Hierarchy**

#### Problem
Long lists of phases become hard to scan.

#### Solution: Enhanced Visual Design
- **Color coding**: Allow custom colors per phase
- **Icons**: Add icons to phases for quick identification
- **Progress indicators**: Show completion stats per phase
- **Compact/Expanded toggle**: Global collapse/expand all phases

**UI Design:**
```
🎨 Phase Colors:
┌────────────────────┐ ┌────────────────────┐
│ 🟦 Pre-Arrival     │ │ 🟩 First Day       │
│    Setup           │ │    Orientation     │
│ ────────────────   │ │ ────────────────   │
│ □ Step 1           │ │ ✓ Step 4           │
│ □ Step 2           │ │ ✓ Step 5           │
│ □ Step 3           │ │ □ Step 6           │
│ 0/3 complete       │ │ 2/3 complete       │
└────────────────────┘ └────────────────────┘
```

---

### 9. **Keyboard Shortcuts & Power User Features**

#### Problem
Power users waste time clicking through UI for repetitive actions.

#### Solution: Add Keyboard Navigation
- **Shortcuts overlay**: Press `?` to show all shortcuts
- **Common shortcuts**:
  - `Cmd/Ctrl + S` - Save
  - `Cmd/Ctrl + E` - Export
  - `Cmd/Ctrl + Z` - Undo
  - `Cmd/Ctrl + D` - Duplicate selected item
  - `Delete` - Delete selected item
  - `Tab` / `Shift+Tab` - Navigate between fields
  - `Enter` - Add new step (when focused on step)
  - `Cmd/Ctrl + ↑/↓` - Move item up/down

**UI Design:**
```
Press ? for keyboard shortcuts
┌────────────────────────────────┐
│ Keyboard Shortcuts             │
├────────────────────────────────┤
│ Cmd+S      Save changes        │
│ Cmd+E      Export playbook     │
│ Cmd+Z      Undo                │
│ Delete     Delete selected     │
│ Enter      Add new step        │
│ Cmd+↑/↓    Move item           │
│ ?          Show this help      │
└────────────────────────────────┘
```

---

### 10. **Preview Mode**

#### Problem
Hard to visualize how the playbook looks to end users while editing.

#### Solution: Add Side-by-Side Preview
- **Split view**: Editor on left, preview on right
- **Toggle preview**: Show how instance will look
- **Mobile preview**: See responsive view
- **Print preview**: How exported PDF will look

**UI Design:**
```
[Edit Mode] [Preview Mode] [Split View]

┌─────────────┬─────────────┐
│ EDITOR      │ PREVIEW     │
│             │             │
│ Phase 1:... │ ✓ Phase 1   │
│ [editing]   │   Step 1 ☐  │
│             │   Step 2 ☐  │
│             │             │
│ Phase 2:... │ ○ Phase 2   │
│             │   (locked)  │
└─────────────┴─────────────┘
```

---

### 11. **Better Access from Playbooks Library**

#### Problem
Edit action might be buried in 3-dot menu or require extra clicks.

#### Solution: Multiple Access Points
1. **Quick Edit icon**: Always visible on card hover (for simple edits)
2. **3-dot menu**: Full edit option with submenu:
   - "Quick Edit Details" (inline)
   - "Edit Workflow" (full editor)
   - "Edit as Template" (duplicate then edit)
3. **Batch edit mode**: Edit multiple playbooks' metadata at once

**UI Design (Grid View Card):**
```
┌──────────────────────────────┐
│ New Employee Onboarding  [⋮] │ ← 3-dot menu
│ ────────────────────────     │
│ Standardize how new...       │
│                              │
│ Owner: Dominic    Used: 12x  │
│                              │
│ [View] [✏️ Edit]              │ ← Direct edit button
└──────────────────────────────┘
     ↑ Hover shows edit icon
```

---

### 12. **Edit Activity Log**

#### Problem
No visibility into who changed what and when.

#### Solution: Add Change Log Tab
- **Activity feed**: Show all edits made to playbook
- **Filter by user**: See changes by specific team member
- **Filter by type**: Only show phase additions, step deletions, etc.
- **Revert individual changes**: Undo specific edits

**UI Design:**
```
┌────────────────────────────────────┐
│ Activity Log                       │
├────────────────────────────────────┤
│ 🔵 Today, 2:45 PM - Dominic A.    │
│    Renamed "Setup Phase" to        │
│    "Pre-Arrival Setup"             │
│    [Revert]                        │
│                                    │
│ 🟢 Today, 2:30 PM - Sarah J.      │
│    Added step "Order Equipment"    │
│    to Phase 1                      │
│    [Revert]                        │
│                                    │
│ 🔴 Mar 17, 4:15 PM - John D.      │
│    Deleted Phase 4                 │
│    [Restore]                       │
└────────────────────────────────────┘
```

---

## 🎨 Visual Design Improvements

### Typography Enhancements
- **Phase names**: Increase font weight to 600 (currently looks light)
- **Step numbers**: Add subtle numbering (1.1, 1.2, etc.)
- **Placeholder text**: Make more descriptive and helpful

### Color & Visual Feedback
- **Hover states**: Add subtle background color on phase/step hover
- **Drag preview**: Show ghost/shadow of item being dragged
- **Success animations**: Green checkmark animation on save
- **Error states**: Red border + message for validation errors

### Spacing & Layout
- **Tighter vertical spacing**: Reduce gap between steps for better scanning
- **Phase spacing**: Increase gap between phases for clear separation
- **Collapsible sidebar**: Make details panel collapsible for more editing space

---

## 📊 Priority Matrix

| Improvement | Impact | Effort | Priority |
|-------------|--------|--------|----------|
| Quick Edit Mode | High | Low | 🔴 High |
| Unsaved Changes Warning | High | Low | 🔴 High |
| Keyboard Shortcuts | High | Medium | 🟡 Medium |
| Better Access Points | High | Low | 🔴 High |
| Bulk Actions | Medium | High | 🟢 Low |
| Version History | Medium | High | 🟢 Low |
| Preview Mode | Medium | Medium | 🟡 Medium |
| Smart Templates | Low | High | 🟢 Low |
| Collaborative Editing | Low | Very High | 🟢 Low |
| Rich Text Editing | Medium | Medium | 🟡 Medium |
| Visual Hierarchy | High | Low | 🔴 High |
| Edit Activity Log | Low | Medium | 🟢 Low |

---

## 🚀 Quick Wins (Implement First)

### 1. Visual Hierarchy Improvements (1-2 hours)
- Add phase numbering (1, 2, 3...)
- Increase phase name font weight
- Add subtle hover states
- Improve color contrast

### 2. Quick Edit in Library (2-3 hours)
- Double-click to edit name/description inline
- ESC to cancel, Enter to save
- Show edit icon on hover

### 3. Keyboard Shortcuts (2-3 hours)
- Cmd+S to save
- Delete key to remove items
- Tab navigation between fields
- Shortcuts help overlay

### 4. Unsaved Changes Warning (1 hour)
- Browser beforeunload confirmation
- Visual indicator (already done)
- localStorage auto-save draft

### 5. Better Edit Button Visibility (1 hour)
- Move Edit from 3-dot menu to primary action
- Show on hover in grid view
- Always visible in list view

---

## 💡 Implementation Roadmap

### Phase 1: Essential UX (Week 1)
- ✅ Quick edit mode in library
- ✅ Keyboard shortcuts
- ✅ Unsaved changes warning
- ✅ Visual hierarchy improvements
- ✅ Better edit button placement

### Phase 2: Power Features (Week 2-3)
- ⏳ Bulk actions & multi-select
- ⏳ Preview mode (split view)
- ⏳ Rich text descriptions
- ⏳ Phase color coding & icons

### Phase 3: Advanced Features (Week 4-6)
- 🔮 Version history & restore
- 🔮 Smart templates & suggestions
- 🔮 Edit activity log
- 🔮 Collaborative editing

---

## 🎯 Success Metrics

Track these metrics to measure improvement:

1. **Edit Completion Rate**: % of edits that result in saved changes
2. **Time to Edit**: Average time from opening editor to saving
3. **Edit Frequency**: Number of edits per playbook per month
4. **Error Rate**: Number of accidental deletions/unsaved changes
5. **User Satisfaction**: Survey scores for editing experience

---

## 🔧 Technical Considerations

### Performance
- Debounce inline editing to reduce renders
- Virtualize long lists of phases/steps
- Lazy load version history data
- Optimize drag-and-drop calculations

### Accessibility
- ARIA labels for all interactive elements
- Keyboard navigation for all actions
- Screen reader announcements for changes
- Focus management during modal interactions

### Data Integrity
- Client-side validation before save
- Conflict resolution for simultaneous edits
- Backup before destructive actions
- Undo/redo stack implementation

---

## 📝 User Testing Questions

Before implementing, test with stakeholders:

1. How often do you edit playbook templates?
2. What's the most frustrating part of editing?
3. Do you prefer inline editing or full-page editor?
4. Would you use keyboard shortcuts if available?
5. How important is version history to you?
6. Do you collaborate with others on playbooks?
7. What information do you most frequently edit?

---

## Final Recommendations

**Start with these 3 improvements for maximum impact:**

1. **Quick Edit Mode** - Fastest path for simple changes
2. **Visual Hierarchy** - Makes scanning and editing easier
3. **Keyboard Shortcuts** - Power users will love this

These require minimal development effort but significantly improve the editing experience for both casual and power users.
