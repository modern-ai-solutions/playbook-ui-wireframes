
  # Playbook Ui

  This is a code bundle for Playbook Ui. The original project is available at https://www.figma.com/design/OiHgMlZFrUqFy26sjrUGog/Playbook-Ui.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  