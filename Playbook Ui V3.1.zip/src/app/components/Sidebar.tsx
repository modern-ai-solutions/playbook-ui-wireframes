import { LayoutDashboard, FileText, HelpCircle } from 'lucide-react';

interface SidebarProps {
  onNavigate: (view: 'overview' | 'create') => void;
  currentView: string;
}

export function Sidebar({ onNavigate, currentView }: SidebarProps) {
  return (
    <div className="w-[240px] bg-[#2D7E76] text-white flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-[#2D7E76] rounded"></div>
          </div>
          <span className="text-xl font-semibold">PathFinder</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 pt-4">
        <button
          onClick={() => onNavigate('overview')}
          className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-white/10 transition-colors ${
            currentView === 'overview' ? 'bg-white/10' : ''
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span>Playbooks</span>
        </button>
        <button
          onClick={() => onNavigate('create')}
          className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-white/10 transition-colors ${
            currentView === 'create' ? 'bg-white/10' : ''
          }`}
        >
          <FileText className="w-5 h-5" />
          <span>Create Playbook</span>
        </button>
      </nav>

      {/* Help */}
      <div className="p-6 border-t border-white/20">
        <button className="w-full flex items-center gap-3 py-2 hover:bg-white/10 rounded transition-colors">
          <HelpCircle className="w-5 h-5" />
          <span>Help</span>
        </button>
      </div>
    </div>
  );
}