import { X, Calendar as CalendarIcon, Users, ChevronDown } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { useState, useRef, useEffect } from 'react';

interface ConfigureInstanceDialogProps {
  open: boolean;
  onClose: () => void;
  onCreateActivePlaybook: (activePlaybookData: any) => void;
  playbook: {
    id: number;
    name: string;
    description: string;
    phases: number;
  };
}

export function ConfigureInstanceDialog({ open, onClose, onCreateActivePlaybook, playbook }: ConfigureInstanceDialogProps) {
  const [dateValue, setDateValue] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [openOwnerDropdown, setOpenOwnerDropdown] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activePlaybookDescription, setActivePlaybookDescription] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Mock user data for the combobox
  const availableUsers = [
    'Sarah Johnson',
    'Michael Chen',
    'Emily Rodriguez',
    'David Kim',
    'Rachel Thompson',
    'James Wilson',
    'Lisa Anderson',
    'Alex Martinez',
  ];

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpenOwnerDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectUser = (user: string) => {
    if (!selectedUsers.includes(user)) {
      setSelectedUsers([...selectedUsers, user]);
    }
    setSearchTerm('');
    setOpenOwnerDropdown(false);
  };

  const handleRemoveUser = (user: string) => {
    setSelectedUsers(selectedUsers.filter(u => u !== user));
  };

  const filteredUsers = availableUsers.filter(
    user => 
      !selectedUsers.includes(user) && 
      user.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateActivePlaybook = () => {
    onCreateActivePlaybook({
      playbookId: playbook.id,
      dueDate: dateValue,
      owners: selectedUsers,
      description: activePlaybookDescription,
    });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0" onPointerDownOutside={(e) => e.preventDefault()}>
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4">
          <DialogTitle className="text-xl font-semibold text-[#006B7D]">
            Configure Active Playbook
          </DialogTitle>
          <p className="text-sm text-gray-600 mt-1">
            Set up your new active playbook with the required information
          </p>
        </div>

        {/* Content */}
        <div className="px-6 py-6 space-y-6">
          {/* Playbook Information - Read Only */}
          <div>
            <h3 className="text-base font-semibold text-[#006B7D] mb-3">
              Playbook Information
            </h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-5">
              <div className="space-y-2.5">
                <div className="flex gap-3">
                  <span className="text-sm font-semibold text-gray-700 min-w-[90px]">Name:</span>
                  <span className="text-sm text-gray-900">{playbook.name}</span>
                </div>
                <div className="flex gap-3">
                  <span className="text-sm font-semibold text-gray-700 min-w-[90px]">Description:</span>
                  <span className="text-sm text-gray-900">{playbook.description}</span>
                </div>
                <div className="flex gap-3">
                  <span className="text-sm font-semibold text-gray-700 min-w-[90px]">Phases:</span>
                  <span className="text-sm text-gray-900">{playbook.phases}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Form fields */}
          <div className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-4 items-center">
            {/* Due Date */}
            <Label htmlFor="dueDate" className="text-sm font-semibold text-gray-700 text-right">
              Due Date
            </Label>
            <input
              id="dueDate"
              type="date"
              value={dateValue}
              onChange={(e) => setDateValue(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#006B7D] focus:border-transparent"
            />

            {/* Active Playbook Owner */}
            <Label className="text-sm font-semibold text-gray-700 text-right self-start mt-2">
              Owner
            </Label>
            <div>
              {selectedUsers.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-2">
                  {selectedUsers.map((user) => (
                    <div
                      key={user}
                      className="inline-flex items-center gap-2 bg-[#006B7D]/10 text-[#006B7D] px-3 py-1.5 rounded-full text-sm"
                    >
                      <Users className="w-3 h-3" />
                      {user}
                      <button onClick={() => handleRemoveUser(user)} className="hover:text-[#005568]">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div ref={dropdownRef} className="relative">
                <button
                  type="button"
                  onClick={() => setOpenOwnerDropdown(!openOwnerDropdown)}
                  className="w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 text-sm"
                >
                  <span className="text-gray-500">Select owner...</span>
                  <ChevronDown className={`ml-2 h-4 w-4 text-gray-400 transition-transform ${openOwnerDropdown ? 'rotate-180' : ''}`} />
                </button>
                {openOwnerDropdown && (
                  <div className="absolute top-full mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-[240px] overflow-y-auto">
                    {filteredUsers.length > 0 ? (
                      filteredUsers.map((user) => (
                        <button
                          key={user}
                          type="button"
                          onClick={() => handleSelectUser(user)}
                          className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-100 text-sm text-left"
                        >
                          <Users className="w-4 h-4 text-gray-500" />
                          {user}
                        </button>
                      ))
                    ) : (
                      <div className="px-3 py-6 text-center text-sm text-gray-500">
                        No users found.
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Active Playbook Description */}
            <Label htmlFor="activePlaybookDescription" className="text-sm font-semibold text-gray-700 text-right self-start mt-2">
              Description
            </Label>
            <Textarea
              id="activePlaybookDescription"
              value={activePlaybookDescription}
              onChange={(e) => setActivePlaybookDescription(e.target.value)}
              placeholder="Describe the purpose and context of this active playbook..."
              className="min-h-[100px] bg-white border-gray-300 resize-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4 flex items-center justify-end gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="px-6 border-gray-300 hover:bg-gray-50"
          >
            Cancel
          </Button>
          <Button
            onClick={handleCreateActivePlaybook}
            className="px-6 bg-[#006B7D] hover:bg-[#005568] text-white"
          >
            Create Active Playbook
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}