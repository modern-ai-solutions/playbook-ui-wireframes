import { Search, Plus, Grid3x3, List, User, Calendar, CheckCircle2, FileCheck, Zap, Play, MoreVertical, Eye, Trash2, Home, ArrowLeft, Download, Copy, Archive, FileJson, FileSpreadsheet, FileText } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from './ui/dropdown-menu';
import { DeleteConfirmationDialog } from './DeleteConfirmationDialog';
import { useState } from 'react';

interface InstancesLibraryProps {
  onCreateActivePlaybook: (playbookId: number) => void;
  onContinueActivePlaybook: (activePlaybookId: number) => void;
  onBackHome?: () => void;
}

const activePlaybooks = [
  {
    id: 1,
    playbookId: 1,
    playbookName: 'Customer Onboarding',
    description: 'Standardize Customer Onboarding so every new employee gets a consistent onboarding experience.',
    owner: 'Zakariya Jama',
    timesUsed: 0,
    created: '03/02/2026',
    dueDate: '03/15/2026',
    status: 'active',
    progress: 0,
    totalSteps: 12,
    completedSteps: 0,
  },
  {
    id: 2,
    playbookId: 2,
    playbookName: 'Incident Response',
    description: 'Define a clear Incident Response',
    owner: 'Dominic Avellani',
    timesUsed: 2,
    created: '02/26/2026',
    dueDate: '03/10/2026',
    status: 'active',
    progress: 35,
    totalSteps: 15,
    completedSteps: 5,
  },
  {
    id: 3,
    playbookId: 3,
    playbookName: 'Customer Onboarding - Example',
    description: 'Guide the client from kickoff to successful handoff with clear ownership and',
    owner: 'Dominic Avellani',
    timesUsed: 0,
    created: '02/26/2026',
    dueDate: '03/20/2026',
    status: 'active',
    progress: 0,
    totalSteps: 8,
    completedSteps: 0,
  },
  {
    id: 4,
    playbookId: 1,
    playbookName: 'New Employee Onboarding',
    description: 'Run New Employee Onboarding so every new employee gets a consistent onboarding experience.',
    owner: 'Sarah Johnson',
    timesUsed: 3,
    created: '02/20/2026',
    dueDate: '03/05/2026',
    status: 'active',
    progress: 75,
    totalSteps: 20,
    completedSteps: 15,
  },
];

export function InstancesLibrary({ onCreateActivePlaybook, onContinueActivePlaybook, onBackHome }: InstancesLibraryProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [activePlaybookToDelete, setActivePlaybookToDelete] = useState<typeof activePlaybooks[0] | null>(null);
  const [completedActivePlaybooks, setCompletedActivePlaybooks] = useState<Set<number>>(new Set([4])); // Active playbook 4 starts as completed (75% progress)
  const [deletedActivePlaybooks, setDeletedActivePlaybooks] = useState<Set<number>>(new Set());
  const [statusFilter, setStatusFilter] = useState('in-progress');

  const handleMarkComplete = (activePlaybookId: number) => {
    const newCompleted = new Set(completedActivePlaybooks);
    if (newCompleted.has(activePlaybookId)) {
      newCompleted.delete(activePlaybookId);
    } else {
      newCompleted.add(activePlaybookId);
    }
    setCompletedActivePlaybooks(newCompleted);
  };

  const handleDuplicate = (activePlaybookId: number) => {
    console.log('Duplicating active playbook:', activePlaybookId);
    // In a real app, this would create a copy
  };

  const handleExportJSON = (playbook: any) => {
    const dataStr = JSON.stringify(playbook, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `${playbook.playbookName.replace(/\s+/g, '_')}_${playbook.id}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleExportCSV = (playbook: any) => {
    const csvContent = [
      ['Field', 'Value'],
      ['Active Playbook ID', playbook.id],
      ['Playbook Name', playbook.playbookName],
      ['Description', playbook.description],
      ['Owner', playbook.owner],
      ['Created', playbook.created],
      ['Due Date', playbook.dueDate],
      ['Status', playbook.status],
      ['Progress', `${playbook.progress}%`],
      ['Completed Steps', playbook.completedSteps],
      ['Total Steps', playbook.totalSteps],
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    
    const dataUri = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
    const exportFileDefaultName = `${playbook.playbookName.replace(/\s+/g, '_')}_${playbook.id}.csv`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleExportTXT = (playbook: any) => {
    const txtContent = `
Active Playbook Report
======================

Active Playbook ID: ${playbook.id}
Playbook Name: ${playbook.playbookName}
Description: ${playbook.description}

Details:
--------
Owner: ${playbook.owner}
Created: ${playbook.created}
Due Date: ${playbook.dueDate}
Status: ${playbook.status}

Progress:
---------
${playbook.completedSteps} of ${playbook.totalSteps} steps completed (${playbook.progress}%)
    `.trim();
    
    const dataUri = 'data:text/plain;charset=utf-8,' + encodeURIComponent(txtContent);
    const exportFileDefaultName = `${playbook.playbookName.replace(/\s+/g, '_')}_${playbook.id}.txt`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleDeleteClick = (playbook: typeof activePlaybooks[0]) => {
    setActivePlaybookToDelete(playbook);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (activePlaybookToDelete) {
      handleDelete(activePlaybookToDelete.id);
    }
  };

  const handleDelete = (activePlaybookId: number) => {
    const newDeleted = new Set(deletedActivePlaybooks);
    newDeleted.add(activePlaybookId);
    setDeletedActivePlaybooks(newDeleted);
  };

  // Filter active playbooks based on status filter
  const filteredActivePlaybooks = activePlaybooks.filter(playbook => {
    if (deletedActivePlaybooks.has(playbook.id)) return false;
    
    if (statusFilter === 'in-progress') {
      return !completedActivePlaybooks.has(playbook.id);
    } else if (statusFilter === 'completed') {
      return completedActivePlaybooks.has(playbook.id);
    }
    return true; // 'all'
  });

  const getStatusBadge = (status: string) => {
    if (status === 'active') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
          <CheckCircle2 className="w-3 h-3" />
          Active
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
        <FileCheck className="w-3 h-3" />
        Draft
      </span>
    );
  };

  const getProgressBar = (progress: number) => {
    return (
      <div className="w-full">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-gray-600">Progress</span>
          <span className="text-xs font-medium text-gray-900">{progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-[#006B7D] h-2 rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col overflow-auto">
      {/* Header */}
      <div className="px-12 pt-12 pb-8">
        <div className="mb-6">
          {onBackHome && (
            <button
              onClick={onBackHome}
              className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          )}
          <div>
            <h1 className="text-[#0E7490] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
              Active Playbooks
            </h1>
            <p className="text-gray-600 text-sm">Track and manage your active playbooks</p>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="px-12 pb-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search active playbooks..."
                className="pl-10 bg-gray-50 border-gray-200 text-sm"
              />
            </div>

            <div className="flex items-center gap-3 ml-auto">
              {/* Status Filter */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="all">All Active Playbooks</SelectItem>
                </SelectContent>
              </Select>

              {/* Sort */}
              <Select defaultValue="duedate">
                <SelectTrigger className="w-40 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="duedate">Due Date</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="progress">Progress</SelectItem>
                </SelectContent>
              </Select>

              {/* View Toggle */}
              <div className="flex items-center gap-0 bg-gray-100 rounded p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'grid' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'list' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-12 pb-12">
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredActivePlaybooks.map((playbook) => (
              <Card 
                key={playbook.id} 
                className="bg-white border-gray-200 hover:shadow-lg transition-all relative group"
              >
                <CardContent className="p-6">
                  {/* 3-dot Menu */}
                  <div className="absolute top-4 right-4 z-10">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="h-8 w-8 flex items-center justify-center rounded-md text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuSub>
                          <DropdownMenuSubTrigger className="gap-2 cursor-pointer">
                            <Download className="w-4 h-4 text-gray-500" />
                            Export
                          </DropdownMenuSubTrigger>
                          <DropdownMenuSubContent>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportJSON(playbook)}
                            >
                              <FileJson className="w-4 h-4 text-gray-500" />
                              JSON File
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportCSV(playbook)}
                            >
                              <FileSpreadsheet className="w-4 h-4 text-gray-500" />
                              CSV File
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleExportTXT(playbook)}
                            >
                              <FileText className="w-4 h-4 text-gray-500" />
                              Text File
                            </DropdownMenuItem>
                          </DropdownMenuSubContent>
                        </DropdownMenuSub>
                        <DropdownMenuItem 
                          className="gap-2 cursor-pointer"
                          onClick={() => handleDuplicate(playbook.id)}
                        >
                          <Copy className="w-4 h-4 text-gray-500" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="gap-2 cursor-pointer"
                          onClick={() => handleMarkComplete(playbook.id)}
                        >
                          <CheckCircle2 className="w-4 h-4 text-gray-500" />
                          {completedActivePlaybooks.has(playbook.id) ? 'Mark as In Progress' : 'Mark as Complete'}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          className="gap-2 cursor-pointer text-red-600 focus:text-red-600"
                          onClick={() => handleDeleteClick(playbook)}
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Title and Description */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 pr-10">
                    {playbook.playbookName}
                  </h3>
                  <p className="text-sm text-gray-600 mb-6 leading-relaxed line-clamp-2">
                    {playbook.description}
                  </p>

                  {/* Progress Bar */}
                  <div className="mb-6">
                    {getProgressBar(playbook.progress)}
                    <p className="text-xs text-gray-500 mt-1">
                      {playbook.completedSteps} of {playbook.totalSteps} steps completed
                    </p>
                  </div>

                  {/* Metadata with Icons */}
                  <div className="space-y-2.5 mb-6 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900 font-medium">{playbook.owner}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Due: <span className="text-gray-900 font-medium">{playbook.dueDate}</span></span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 text-white text-sm h-10 font-medium"
                      style={{ backgroundColor: '#006B7D' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#006B7D'}
                      onClick={() => onContinueActivePlaybook(playbook.id)}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Continue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {viewMode === 'list' && (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Playbook Name</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Owner</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Progress</th>
                  <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Due Date</th>
                  <th className="text-right px-6 py-2.5 text-sm font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredActivePlaybooks.map((playbook) => (
                  <tr key={playbook.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3">
                      <div>
                        <span className="font-semibold text-gray-900 text-sm">{playbook.playbookName}</span>
                        <p className="text-xs text-gray-500 line-clamp-1">{playbook.description}</p>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-sm text-gray-700">{playbook.owner}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="w-40">
                        {getProgressBar(playbook.progress)}
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-sm text-gray-600">{playbook.dueDate}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-[#006B7D] hover:bg-[#006B7D]/10 h-8 px-3"
                          onClick={() => onContinueActivePlaybook(playbook.id)}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Continue
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-gray-400 hover:text-gray-700 hover:bg-gray-100">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuSub>
                              <DropdownMenuSubTrigger className="gap-2 cursor-pointer">
                                <Download className="w-4 h-4 text-gray-500" />
                                Export
                              </DropdownMenuSubTrigger>
                              <DropdownMenuSubContent>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportJSON(playbook)}
                                >
                                  <FileJson className="w-4 h-4 text-gray-500" />
                                  JSON File
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportCSV(playbook)}
                                >
                                  <FileSpreadsheet className="w-4 h-4 text-gray-500" />
                                  CSV File
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="gap-2 cursor-pointer"
                                  onClick={() => handleExportTXT(playbook)}
                                >
                                  <FileText className="w-4 h-4 text-gray-500" />
                                  Text File
                                </DropdownMenuItem>
                              </DropdownMenuSubContent>
                            </DropdownMenuSub>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleDuplicate(playbook.id)}
                            >
                              <Copy className="w-4 h-4 text-gray-500" />
                              Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer"
                              onClick={() => handleMarkComplete(playbook.id)}
                            >
                              <CheckCircle2 className="w-4 h-4 text-gray-500" />
                              {completedActivePlaybooks.has(playbook.id) ? 'Mark as In Progress' : 'Mark as Complete'}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer text-red-600 focus:text-red-600"
                              onClick={() => handleDeleteClick(playbook)}
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      {deleteDialogOpen && activePlaybookToDelete && (
        <DeleteConfirmationDialog
          open={deleteDialogOpen}
          onClose={() => {
            setDeleteDialogOpen(false);
            setActivePlaybookToDelete(null);
          }}
          onConfirm={() => handleDeleteConfirm()}
          title="Delete Active Playbook"
          description="Are you sure you want to delete this active playbook?"
          itemName={activePlaybookToDelete.playbookName}
          warningMessage={undefined}
        />
      )}
    </div>
  );
}