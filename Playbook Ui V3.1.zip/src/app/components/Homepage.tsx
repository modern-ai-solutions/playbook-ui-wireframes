import { FileText, ListChecks, Plus, Eye, CheckCircle2, Share2 } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

interface HomepageProps {
  onNavigateToPlaybooks: () => void;
  onNavigateToActivePlaybooks: () => void;
  onCreatePlaybook: () => void;
}

export function Homepage({ onNavigateToPlaybooks, onNavigateToActivePlaybooks, onCreatePlaybook }: HomepageProps) {
  return (
    <div className="h-full flex flex-col overflow-auto bg-[#E8EDE8]">
      {/* Header */}
      <div className="px-12 pt-16 pb-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-[#006B7D] mb-3" style={{ fontSize: '36px', fontWeight: 600 }}>
            Playbooks
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl">
            Build reusable playbooks, run them as active workflows, and track progress across your team.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-12 pb-16">
        <div className="max-w-6xl mx-auto">
          {/* Library Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {/* Playbook Library Card */}
            <Card className="bg-white border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-lg bg-[#006B7D] flex items-center justify-center">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-gray-900">Playbook Library</h2>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Build and manage reusable workflow templates. Define phases, steps, and ownership once — then run them as many times as you need.
                </p>
                
                <div className="space-y-3">
                  <Button
                    onClick={onNavigateToPlaybooks}
                    className="w-full bg-[#006B7D] hover:bg-[#005568] text-white h-12 text-base font-medium"
                  >
                    <Eye className="w-5 h-5 mr-2" />
                    View Playbooks
                  </Button>
                  <Button
                    onClick={onCreatePlaybook}
                    variant="outline"
                    className="w-full border-[#006B7D] text-[#006B7D] hover:bg-[#006B7D]/10 h-12 text-base font-medium"
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Create New Playbook
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Instances Library Card */}
            <Card className="bg-white border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-lg bg-[#0E7490] flex items-center justify-center">
                    <ListChecks className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-gray-900">Active Playbooks</h2>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Run your playbooks as live workflows. Assign owners, set due dates, and track step-by-step progress across your team's ongoing work.
                </p>
                
                <div className="space-y-3">
                  <Button
                    onClick={onNavigateToActivePlaybooks}
                    className="w-full bg-[#006B7D] hover:bg-[#005568] text-white h-12 text-base font-medium"
                  >
                    <Eye className="w-5 h-5 mr-2" />
                    View Active Playbooks
                  </Button>
                  <Button
                    onClick={onNavigateToPlaybooks}
                    variant="outline"
                    className="w-full border-[#006B7D] text-[#006B7D] hover:bg-[#006B7D]/10 h-12 text-base font-medium"
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Run a Playbook
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* How It Works Section */}
          <div className="bg-white rounded-lg border border-gray-200 p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">How It Works</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Step 1 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  1
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Create a Playbook</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Define workflow phases, steps, and assign ownership to standardize your team's processes.
                </p>
              </div>

              {/* Step 2 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  2
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Run It as a Workflow</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Launch an active playbook from any template, assign owners, set due dates, and work through each step.
                </p>
              </div>

              {/* Step 3 */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#006B7D] text-white text-xl font-semibold mb-4">
                  3
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Track & Complete</h4>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Monitor progress, collaborate with your team, and mark workflows complete when the work is done.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}