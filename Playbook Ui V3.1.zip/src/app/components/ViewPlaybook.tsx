import { ArrowLeft, ChevronDown, ChevronRight, Download, FileJson, FileText, File } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from './ui/dropdown-menu';

const TEAL = '#006B7D';

interface ViewPlaybookProps {
  playbookId: number;
  onBack: () => void;
  onUsePlaybook: (playbookId: number) => void;
}

// Mock data - simulating a saved playbook with phases and steps
const mockPlaybooks: Record<number, any> = {
  1: {
    id: 1,
    title: 'New Employee Onboarding',
    description: 'Standardize how new employees are welcomed and trained',
    owner: 'Dominic Avellam',
    instances: 12,
    created: '02/26/2026',
    phases: [
      {
        id: 'phase-1',
        name: 'Pre-Arrival Setup',
        description: 'Prepare everything before the new employee arrives',
        steps: [
          {
            id: 'step-1',
            name: 'Create Email Account',
            description: 'Set up company email and grant necessary permissions',
          },
          {
            id: 'step-2',
            name: 'Order Equipment',
            description: 'Order laptop, monitor, and other required hardware',
          },
          {
            id: 'step-3',
            name: 'Prepare Workspace',
            description: 'Set up desk, chair, and office supplies',
          },
        ],
      },
      {
        id: 'phase-2',
        name: 'First Day Orientation',
        description: 'Welcome and onboard the employee on day one',
        steps: [
          {
            id: 'step-4',
            name: 'Welcome Meeting',
            description: 'Introduction with the team and company overview',
          },
          {
            id: 'step-5',
            name: 'IT Setup',
            description: 'Configure computer, software, and access credentials',
          },
          {
            id: 'step-6',
            name: 'Office Tour',
            description: 'Show key areas: restrooms, kitchen, emergency exits',
          },
        ],
      },
      {
        id: 'phase-3',
        name: 'First Week Training',
        description: 'Initial training and department introductions',
        steps: [
          {
            id: 'step-7',
            name: 'Role-Specific Training',
            description: 'Training on job responsibilities and tools',
          },
          {
            id: 'step-8',
            name: 'Meet Key Stakeholders',
            description: 'Schedule meetings with cross-functional teams',
          },
        ],
      },
    ],
  },
  2: {
    id: 2,
    title: 'Client Welcome Process',
    description: 'Ensure every new client gets a consistent onboarding experience',
    owner: 'Dominic Avellam',
    instances: 8,
    created: '02/19/2026',
    phases: [
      {
        id: 'phase-1',
        name: 'Initial Contact',
        description: 'First touchpoint with the client',
        steps: [
          {
            id: 'step-1',
            name: 'Send Welcome Email',
            description: 'Personalized welcome message with next steps',
          },
          {
            id: 'step-2',
            name: 'Schedule Kickoff Call',
            description: 'Book initial consultation meeting',
          },
        ],
      },
      {
        id: 'phase-2',
        name: 'Account Setup',
        description: 'Create and configure client accounts',
        steps: [
          {
            id: 'step-3',
            name: 'Create Client Portal Access',
            description: 'Set up login credentials and portal access',
          },
          {
            id: 'step-4',
            name: 'Assign Account Manager',
            description: 'Designate primary point of contact',
          },
        ],
      },
    ],
  },
  3: {
    id: 3,
    title: 'Weekly Team Reporting',
    description: 'Automated weekly reports for team progress tracking',
    owner: 'Tim Donato',
    instances: 24,
    created: '06/18/2025',
    phases: [
      {
        id: 'phase-1',
        name: 'Data Collection',
        description: 'Gather metrics from all team members',
        steps: [
          {
            id: 'step-1',
            name: 'Send Status Form',
            description: 'Email weekly status update form to team',
          },
        ],
      },
    ],
  },
};

export function ViewPlaybook({ playbookId, onBack, onUsePlaybook }: ViewPlaybookProps) {
  const [expandedPhases, setExpandedPhases] = useState<Set<string>>(new Set());
  
  const playbook = mockPlaybooks[playbookId];

  if (!playbook) {
    return (
      <div className="h-full flex items-center justify-center">
        <p className="text-gray-600">Playbook not found</p>
      </div>
    );
  }

  const togglePhase = (phaseId: string) => {
    const newExpanded = new Set(expandedPhases);
    if (newExpanded.has(phaseId)) {
      newExpanded.delete(phaseId);
    } else {
      newExpanded.add(phaseId);
    }
    setExpandedPhases(newExpanded);
  };

  return (
    <div className="h-full flex flex-col overflow-auto bg-[#E8EDE8]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-12 py-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-6 text-gray-700 hover:bg-gray-100 -ml-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Library
        </Button>

        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">
              {playbook.title}
            </h1>
            <p className="text-gray-600">
              {playbook.description}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  className="text-white gap-2"
                  style={{ backgroundColor: TEAL }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
                >
                  <Download className="w-4 h-4" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem>
                  <FileJson className="w-4 h-4 mr-2" />
                  Export as JSON
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <FileText className="w-4 h-4 mr-2" />
                  Export as CSV
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <File className="w-4 h-4 mr-2" />
                  Export as Text
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <FileText className="w-4 h-4 mr-2" />
                  Export as PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              className="text-white"
              style={{ backgroundColor: TEAL }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = TEAL}
              onClick={() => onUsePlaybook(playbookId)}
            >
              Use Playbook
            </Button>
          </div>
        </div>
      </div>

      {/* Phases & Steps Content */}
      <div className="flex-1 px-12 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-[260px_1fr] gap-6 items-start">

            {/* Left sidebar — Playbook Info */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 sticky top-6">
              <h3 className="font-semibold text-gray-900 mb-5 text-base">Details</h3>
              <div className="space-y-3">
                <div className="text-sm flex items-baseline gap-1">
                  <span className="text-gray-500 shrink-0">Owner:</span>
                  <span className="font-medium text-gray-900">{playbook.owner}</span>
                </div>
                <div className="text-sm flex items-baseline gap-1">
                  <span className="text-gray-500 shrink-0">Active Playbooks:</span>
                  <span className="font-medium text-gray-900">{playbook.instances}</span>
                </div>
                <div className="text-sm flex items-baseline gap-1">
                  <span className="text-gray-500 shrink-0">Created:</span>
                  <span className="font-medium text-gray-900">{playbook.created}</span>
                </div>
              </div>
            </div>

            {/* Right — Phases & Steps */}
            <div>
              <div className="space-y-4">
                {playbook.phases.map((phase: any, phaseIndex: number) => {
                  const isExpanded = expandedPhases.has(phase.id);
                  
                  return (
                    <Card 
                      key={phase.id} 
                      className="bg-white border-2 transition-all"
                      style={{
                        borderColor: '#D1D5DB',
                      }}
                    >
                      <CardContent className="p-0">
                        {/* Phase Header */}
                        <button
                          onClick={() => togglePhase(phase.id)}
                          className="w-full p-6 flex items-center gap-4 hover:bg-gray-50 transition-colors text-left"
                        >
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                            style={{ backgroundColor: TEAL }}
                          >
                            {phaseIndex + 1}
                          </div>

                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 text-base mb-1">
                              {phase.name}
                            </h3>
                            <p className="text-sm text-gray-600">
                              {phase.description}
                            </p>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="text-sm text-gray-500">
                              {phase.steps.length} {phase.steps.length === 1 ? 'step' : 'steps'}
                            </span>
                            {isExpanded ? (
                              <ChevronDown className="w-5 h-5 text-gray-500" />
                            ) : (
                              <ChevronRight className="w-5 h-5 text-gray-500" />
                            )}
                          </div>
                        </button>

                        {/* Steps (if expanded) */}
                        {isExpanded && phase.steps.length > 0 && (
                          <div className="border-t border-gray-200 bg-gray-50">
                            {phase.steps.map((step: any, stepIndex: number) => (
                              <div 
                                key={step.id} 
                                className="p-5 pl-20 flex items-start gap-4 border-b border-gray-200 last:border-b-0"
                              >
                                <div 
                                  className="w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0"
                                  style={{ backgroundColor: TEAL }}
                                >
                                  {stepIndex + 1}
                                </div>

                                <div className="flex-1">
                                  <h4 className="font-medium text-gray-900 text-sm mb-1">
                                    {step.name}
                                  </h4>
                                  <p className="text-xs text-gray-600">
                                    {step.description}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}