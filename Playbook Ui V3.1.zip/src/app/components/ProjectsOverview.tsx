import { Search, Plus, Edit, Ban, Heart, Grid3x3, List, Eye, Pencil, Palette, Play, Network, FileText, Trash2, MoreVertical, User, Calendar, CheckCircle2, FileCheck, Zap, Home, ArrowLeft, Archive, Copy } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from './ui/dropdown-menu';
import { ConfigureInstanceDialog } from './ConfigureInstanceDialog';
import { DeleteConfirmationDialog } from './DeleteConfirmationDialog';
import { useState } from 'react';

interface ProjectsOverviewProps {
  onCreateNew?: () => void;
  onViewPlaybook?: (id: number) => void;
  onEditPlaybook?: (id: number) => void;
  onViewRelated?: (id: number) => void;
  onActivePlaybookCreated?: (activePlaybookId?: number) => void;
  onBackHome?: () => void;
}

const playbooks = [
  {
    id: 1,
    title: 'New Employee Onboarding',
    description: 'Standardize how new employees are welcomed and trained',
    owner: 'Dominic Avellam',
    timesUsed: 12,
    created: '02/26/2026',
    status: 'active',
  },
  {
    id: 2,
    title: 'Client Welcome Process',
    description: 'Ensure every new client gets a consistent onboarding experience',
    owner: 'Dominic Avellam',
    timesUsed: 8,
    created: '02/19/2026',
    status: 'active',
  },
  {
    id: 3,
    title: 'Weekly Team Reporting',
    description: 'Automated weekly reports for team progress tracking',
    owner: 'Tim Donato',
    timesUsed: 24,
    created: '06/18/2025',
    status: 'active',
  },
  {
    id: 4,
    title: 'Sales Pipeline Process',
    description: 'Automated sales reporting workflow',
    owner: 'Tim Donato',
    timesUsed: 0,
    created: '06/18/2025',
    status: 'draft',
  },
  {
    id: 5,
    title: 'Security Implementation',
    description: 'Security implementation standard procedures',
    owner: 'Michaela Donato',
    timesUsed: 5,
    created: '06/16/2025',
    status: 'active',
  },
  {
    id: 6,
    title: 'Vendor Management',
    description: 'Inquiry management workflow for vendors',
    owner: 'Paul Galvin',
    timesUsed: 15,
    created: '06/15/2025',
    status: 'active',
  },
];

export function ProjectsOverview({ 
  onCreateNew, 
  onViewPlaybook, 
  onEditPlaybook, 
  onViewRelated,
  onActivePlaybookCreated,
  onBackHome 
}: ProjectsOverviewProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [disabledPlaybooks, setDisabledPlaybooks] = useState<Set<number>>(new Set([3])); // Playbook 3 starts disabled
  const [statusFilter, setStatusFilter] = useState('active');
  const [configureDialogOpen, setConfigureDialogOpen] = useState(false);
  const [selectedPlaybook, setSelectedPlaybook] = useState<typeof playbooks[0] | null>(null);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [favorites, setFavorites] = useState<Set<number>>(new Set([1, 5]));

  const toggleFavorite = (id: number) => {
    setFavorites(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  // Remove old internal handler functions and call props directly below

  const handleToggleDisable = (playbookId: number) => {
    const newDisabled = new Set(disabledPlaybooks);
    if (newDisabled.has(playbookId)) {
      newDisabled.delete(playbookId);
    } else {
      newDisabled.add(playbookId);
    }
    setDisabledPlaybooks(newDisabled);
  };

  const handleDuplicate = (playbookId: number) => {
    console.log('Duplicating playbook:', playbookId);
    // In a real app, this would create a copy
  };

  const handleUsePlaybook = (playbookId: number) => {
    const playbook = playbooks.find(p => p.id === playbookId);
    if (playbook) {
      setSelectedPlaybook(playbook);
      setConfigureDialogOpen(true);
    }
  };

  const handleCreateActivePlaybook = (activePlaybookData: any) => {
    console.log('Creating active playbook:', activePlaybookData);
    // Generate a new active playbook ID (in a real app, this would come from the backend)
    const newActivePlaybookId = Math.floor(Math.random() * 10000) + 1000;
    setConfigureDialogOpen(false);
    if (onActivePlaybookCreated) {
      onActivePlaybookCreated(newActivePlaybookId);
    }
  };

  // Filter playbooks based on status filter
  const filteredPlaybooks = playbooks.filter(playbook => {
    if (statusFilter === 'active') {
      return !disabledPlaybooks.has(playbook.id);
    } else if (statusFilter === 'disabled') {
      return disabledPlaybooks.has(playbook.id);
    }
    return true; // 'all'
  });

  const hasPlaybooks = playbooks.length > 0;

  return (
    <div className="h-full flex flex-col overflow-auto">
      {/* Header */}
      <div className="px-12 pt-12 pb-8">
        <div className="mb-6">
          {onBackHome && (
            <button
              onClick={onBackHome}
              className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          )}
          <div>
            <h1 className="text-[#0E7490] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
              Playbooks Library
            </h1>
            <p className="text-gray-600 text-sm">View and manage your playbooks</p>
          </div>
        </div>
        
        <Button 
          onClick={onCreateNew}
          className="bg-[#0E7490] hover:bg-[#0c6380] text-white gap-2 px-5 py-2 rounded"
        >
          <Plus className="w-4 h-4" />
          Create New Playbook
        </Button>
      </div>

      {/* Filter Bar */}
      <div className="px-12 pb-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search playbooks..."
                className="pl-10 bg-gray-50 border-gray-200 text-sm"
              />
            </div>

            <div className="flex items-center gap-3 ml-auto">
              {/* Status Filter - simplified for non-technical users */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-36 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="disabled">Disabled</SelectItem>
                  <SelectItem value="all">All Playbooks</SelectItem>
                </SelectContent>
              </Select>

              {/* Sort */}
              <Select defaultValue="newest">
                <SelectTrigger className="w-40 bg-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="name">Name A-Z</SelectItem>
                </SelectContent>
              </Select>

              {/* View Toggle */}
              <div className="flex items-center gap-0 bg-gray-100 rounded p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'grid' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-8 w-8 p-0 rounded ${
                    viewMode === 'list' 
                      ? 'bg-[#0E7490] text-white hover:bg-[#0c6380] hover:text-white' 
                      : 'hover:bg-gray-200 text-gray-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-12 pb-12">
        {!hasPlaybooks ? (
          /* Empty State */
          <div className="flex items-center justify-center h-full py-20">
            <div className="text-center max-w-md">
              <div className="mb-6 flex justify-center">
                <div className="w-24 h-24 rounded-full bg-[#006B7D]/10 flex items-center justify-center">
                  <Zap className="w-12 h-12 text-[#006B7D]" />
                </div>
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                Create Your First Playbook
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Playbooks help you automate repetitive workflows and ensure consistency across your team. 
                Get started by clicking the button below to create your first playbook.
              </p>
              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3 text-left">
                  <div className="w-8 h-8 rounded-full bg-[#006B7D] text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                    1
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Name your playbook</p>
                    <p className="text-sm text-gray-600">Give it a clear, descriptive name</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 text-left">
                  <div className="w-8 h-8 rounded-full bg-[#006B7D] text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                    2
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Build your workflow</p>
                    <p className="text-sm text-gray-600">Add phases and steps to create your process</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 text-left">
                  <div className="w-8 h-8 rounded-full bg-[#006B7D] text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                    3
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Start using it</p>
                    <p className="text-sm text-gray-600">Run your playbook whenever you need it</p>
                  </div>
                </div>
              </div>
              <Button 
                onClick={onCreateNew}
                className="bg-[#006B7D] hover:bg-[#005568] text-white gap-2 px-6 py-3 text-base"
                size="lg"
              >
                <Plus className="w-5 h-5" />
                Create Your First Playbook
              </Button>
            </div>
          </div>
        ) : (
          <>
            {viewMode === 'grid' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPlaybooks.map((playbook) => (
                  <Card 
                    key={playbook.id} 
                    className="bg-white border-gray-200 hover:shadow-lg transition-all relative group"
                    onMouseEnter={() => setHoveredCard(playbook.id)}
                    onMouseLeave={() => setHoveredCard(null)}
                  >
                    <CardContent className="p-6 relative">
                      {/* Action Icons - Heart and 3-dot menu */}
                      <div className="absolute top-4 right-4 flex items-center gap-1" style={{ zIndex: 50 }}>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 hover:bg-gray-100"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(playbook.id);
                          }}
                          title={favorites.has(playbook.id) ? "Remove from favorites" : "Add to favorites"}
                        >
                          <Heart 
                            className={`w-5 h-5 ${
                              favorites.has(playbook.id) 
                                ? 'fill-red-500 text-red-500' 
                                : 'text-gray-400'
                            }`}
                          />
                        </Button>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              className="h-8 w-8 p-0 hover:bg-gray-100 text-gray-600 inline-flex items-center justify-center rounded"
                              title="More options"
                              type="button"
                            >
                              <MoreVertical className="w-5 h-5" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48" sideOffset={5}>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => onViewPlaybook?.(playbook.id)}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => onEditPlaybook?.(playbook.id)}
                            >
                              <Pencil className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => onViewRelated?.(playbook.id)}
                            >
                              <Network className="w-4 h-4 mr-2" />
                              View Related
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => console.log('Export clicked', playbook.id)}
                            >
                              <FileText className="w-4 h-4 mr-2" />
                              Export
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => handleDuplicate(playbook.id)}
                            >
                              <Copy className="w-4 h-4 mr-2" />
                              Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => handleToggleDisable(playbook.id)}
                            >
                              <Ban className="w-4 h-4 mr-2" />
                              {disabledPlaybooks.has(playbook.id) ? 'Enable' : 'Disable'}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>

                      {/* Title and Description */}
                      <h3 className="text-lg font-semibold text-gray-900 mb-2 pr-20">
                        {playbook.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                        {playbook.description}
                      </p>

                      {/* Metadata with Icons */}
                      <div className="space-y-2.5 mb-6 text-sm">
                        <div className="flex items-center gap-2 text-gray-600">
                          <User className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-900 font-medium">{playbook.owner}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Zap className="w-4 h-4 text-gray-400" />
                          <span>
                            <span className="text-gray-900 font-medium">{playbook.timesUsed}</span>
                            {' '}times used
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-900 font-medium">{playbook.created}</span>
                        </div>
                      </div>

                      {/* Primary Action Button */}
                      <Button 
                        className="w-full text-white text-base h-12 font-medium"
                        style={{ backgroundColor: '#006B7D' }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#005568'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#006B7D'}
                        onClick={() => handleUsePlaybook(playbook.id)}
                      >
                        <Play className="w-5 h-5 mr-2" />
                        Use This Playbook
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {viewMode === 'list' && (
              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Playbook Name</th>
                      <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700 w-96">Description</th>
                      <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Created By</th>
                      <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Times Used</th>
                      <th className="text-left px-6 py-2.5 text-sm font-semibold text-gray-700">Created</th>
                      <th className="text-right px-6 py-2.5 text-sm font-semibold text-gray-700">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredPlaybooks.map((playbook) => (
                      <tr key={playbook.id} className="hover:bg-gray-50 transition-colors group">
                        <td className="px-6 py-3">
                          <span className="font-semibold text-gray-900 text-sm">{playbook.title}</span>
                        </td>
                        <td className="px-6 py-3 relative">
                          <div className="group/desc relative inline-block">
                            <span className="text-sm text-gray-600 line-clamp-1">
                              {playbook.description}
                            </span>
                            {/* Tooltip on hover */}
                            <div className="invisible group-hover/desc:visible absolute z-10 bg-gray-900 text-white text-xs rounded p-2 bottom-full left-0 mb-1 w-64 shadow-lg">
                              {playbook.description}
                              <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-gray-900"></div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex items-center gap-2">
                            <User className="w-3.5 h-3.5 text-gray-400" />
                            <span className="text-sm text-gray-700">{playbook.owner}</span>
                          </div>
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex items-center gap-2">
                            <Zap className="w-3.5 h-3.5 text-gray-400" />
                            <span className="text-sm text-gray-700">{playbook.timesUsed}</span>
                          </div>
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-3.5 h-3.5 text-gray-400" />
                            <span className="text-sm text-gray-600">{playbook.created}</span>
                          </div>
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex items-center justify-end gap-2">
                            {/* Primary Actions as Visible Buttons */}
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-gray-700 hover:bg-gray-100 h-8 px-3"
                              title="View"
                              onClick={() => onViewPlaybook?.(playbook.id)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-gray-700 hover:bg-gray-100 h-8 px-3"
                              title="Edit"
                              onClick={() => onEditPlaybook?.(playbook.id)}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-[#006B7D] hover:bg-[#006B7D]/10 h-8 px-3"
                              title="Use Playbook"
                              onClick={() => handleUsePlaybook(playbook.id)}
                            >
                              <Play className="w-4 h-4" />
                            </Button>
                            
                            {/* More Actions Dropdown */}
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  className="text-gray-700 hover:bg-gray-100 h-8 px-2"
                                  title="More actions"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-48">
                                <DropdownMenuItem 
                                  className="cursor-pointer"
                                  onClick={() => onViewRelated?.(playbook.id)}
                                >
                                  <Network className="w-4 h-4 mr-2" />
                                  View Related
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="cursor-pointer"
                                  onClick={() => console.log('Export clicked', playbook.id)}
                                >
                                  <FileText className="w-4 h-4 mr-2" />
                                  Export
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="cursor-pointer"
                                  onClick={() => handleDuplicate(playbook.id)}
                                >
                                  <Copy className="w-4 h-4 mr-2" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="cursor-pointer"
                                  onClick={() => handleToggleDisable(playbook.id)}
                                >
                                  <Ban className="w-4 h-4 mr-2" />
                                  {disabledPlaybooks.has(playbook.id) ? 'Enable' : 'Disable'}
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>

      {/* Configure Active Playbook Dialog */}
      {configureDialogOpen && selectedPlaybook && (
        <ConfigureInstanceDialog
          open={configureDialogOpen}
          playbook={{
            id: selectedPlaybook.id,
            name: selectedPlaybook.title,
            description: selectedPlaybook.description,
            phases: 3,
          }}
          onClose={() => setConfigureDialogOpen(false)}
          onCreateActivePlaybook={handleCreateActivePlaybook}
        />
      )}
    </div>
  );
}