import { ArrowLeft, GripVertical, ChevronDown, Plus, Pencil, Trash2, Save, Download, FileJson, FileText, File } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { useState, useRef } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from './ui/dropdown-menu';
import { toast } from 'sonner';

interface EditPlaybookProps {
  playbookId: number;
  onBack: () => void;
  onSave: () => void;
}

// Mock playbook data
const mockPlaybooks: Record<number, any> = {
  1: {
    id: 1,
    name: 'New Employee Onboarding',
    description: 'Standardize how new employees are welcomed and trained',
    owner: 'Dominic Avellam',
    phases: [
      {
        id: 1,
        name: 'Pre-Arrival Setup',
        description: 'Prepare everything before the new employee arrives',
        steps: [
          { id: 1, name: 'Create Email Account', description: 'Set up company email and grant necessary permissions' },
          { id: 2, name: 'Order Equipment', description: 'Order laptop, monitor, and other required hardware' },
          { id: 3, name: 'Prepare Workspace', description: 'Set up desk, chair, and office supplies' },
        ],
      },
      {
        id: 2,
        name: 'First Day Orientation',
        description: 'Welcome and onboard the employee on day one',
        steps: [
          { id: 4, name: 'Welcome Meeting', description: 'Introduction with the team and company overview' },
          { id: 5, name: 'IT Setup', description: 'Configure computer, software, and access credentials' },
          { id: 6, name: 'Office Tour', description: 'Show key areas: restrooms, kitchen, emergency exits' },
        ],
      },
      {
        id: 3,
        name: 'First Week Training',
        description: 'Initial training and department introductions',
        steps: [
          { id: 7, name: 'Role-Specific Training', description: 'Training on job responsibilities and tools' },
          { id: 8, name: 'Meet Key Stakeholders', description: 'Schedule meetings with cross-functional teams' },
        ],
      },
    ],
  },
};

const ItemTypes = {
  PHASE: 'phase',
  STEP: 'step',
};

// Draggable Step Component
interface DraggableStepProps {
  step: any;
  stepIndex: number;
  phaseIndex: number;
  onUpdateStep: (phaseIndex: number, stepIndex: number, field: string, value: any) => void;
  onDeleteStep: (phaseIndex: number, stepIndex: number) => void;
  onMoveStep: (phaseIndex: number, fromIndex: number, toIndex: number) => void;
  isLast: boolean;
}

function DraggableStep({ step, stepIndex, phaseIndex, onUpdateStep, onDeleteStep, onMoveStep, isLast }: DraggableStepProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.STEP,
    item: { stepIndex, phaseIndex },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemTypes.STEP,
    hover: (item: { stepIndex: number; phaseIndex: number }) => {
      if (!ref.current) return;
      if (item.phaseIndex !== phaseIndex) return;
      if (item.stepIndex === stepIndex) return;

      onMoveStep(phaseIndex, item.stepIndex, stepIndex);
      item.stepIndex = stepIndex;
    },
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      className={`flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 transition-colors ${
        !isLast ? 'border-b border-gray-100' : ''
      } ${isDragging ? 'opacity-40' : 'opacity-100'}`}
    >
      {/* Teal square drag handle */}
      <div className="w-6 h-6 bg-[#006B7D] rounded flex items-center justify-center shrink-0 mt-0.5 cursor-grab active:cursor-grabbing">
        <GripVertical className="w-3.5 h-3.5 text-white" />
      </div>

      {/* Step name + description */}
      <div className="flex-1 min-w-0 space-y-1">
        <input
          value={step.name}
          onChange={(e) => onUpdateStep(phaseIndex, stepIndex, 'name', e.target.value)}
          className="w-full bg-transparent text-gray-900 font-medium outline-none border-b border-transparent hover:border-gray-300 focus:border-[#006B7D] transition-colors leading-tight"
          style={{ fontSize: '15px' }}
        />
        <input
          value={step.description}
          onChange={(e) => onUpdateStep(phaseIndex, stepIndex, 'description', e.target.value)}
          className="w-full bg-transparent text-gray-400 outline-none border-b border-transparent hover:border-gray-200 focus:border-gray-300 transition-colors"
          style={{ fontSize: '13px' }}
          placeholder="Step description..."
        />
      </div>

      {/* Red trash */}
      <button
        onClick={() => onDeleteStep(phaseIndex, stepIndex)}
        className="text-red-400 hover:text-red-600 p-0.5 shrink-0 mt-0.5 transition-colors"
        title="Delete step"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
}

// Draggable Phase Component
interface DraggablePhaseProps {
  phase: any;
  phaseIndex: number;
  onUpdatePhase: (phaseIndex: number, field: string, value: any) => void;
  onDeletePhase: (phaseIndex: number) => void;
  onMovePhase: (fromIndex: number, toIndex: number) => void;
  onAddStep: (phaseIndex: number) => void;
  onUpdateStep: (phaseIndex: number, stepIndex: number, field: string, value: any) => void;
  onDeleteStep: (phaseIndex: number, stepIndex: number) => void;
  onMoveStep: (phaseIndex: number, fromIndex: number, toIndex: number) => void;
  collapsed: boolean;
  onToggle: () => void;
}

function DraggablePhase({
  phase,
  phaseIndex,
  onUpdatePhase,
  onDeletePhase,
  onMovePhase,
  onAddStep,
  onUpdateStep,
  onDeleteStep,
  onMoveStep,
  collapsed,
  onToggle,
}: DraggablePhaseProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.PHASE,
    item: { phaseIndex },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemTypes.PHASE,
    hover: (item: { phaseIndex: number }) => {
      if (!ref.current) return;
      if (item.phaseIndex === phaseIndex) return;

      onMovePhase(item.phaseIndex, phaseIndex);
      item.phaseIndex = phaseIndex;
    },
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      className={`rounded-lg border border-gray-200 overflow-hidden ${isDragging ? 'opacity-40' : 'opacity-100'}`}
      style={{ backgroundColor: '#f0f4f0' }}
    >
      {/* Phase Header */}
      <div className="flex items-start gap-2 px-4 py-3">
        {/* Left controls */}
        <div className="text-[#006B7D] cursor-grab active:cursor-grabbing shrink-0 mt-1 opacity-70 hover:opacity-100">
          <GripVertical className="w-4 h-4" />
        </div>
        <button
          className="text-[#006B7D] shrink-0 mt-1 hover:opacity-70 transition-opacity"
          onClick={onToggle}
        >
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`}
          />
        </button>

        {/* Phase name + description */}
        <div className="flex-1 min-w-0 space-y-1">
          <input
            value={phase.name}
            onChange={(e) => onUpdatePhase(phaseIndex, 'name', e.target.value)}
            className="w-full bg-transparent text-[#006B7D] font-semibold outline-none border-b border-transparent hover:border-[#006B7D]/30 focus:border-[#006B7D] transition-colors leading-tight"
            style={{ fontSize: '17px' }}
          />
          <input
            value={phase.description || ''}
            onChange={(e) => onUpdatePhase(phaseIndex, 'description', e.target.value)}
            className="w-full bg-transparent text-gray-500 outline-none border-b border-transparent hover:border-gray-300 focus:border-gray-400 transition-colors"
            style={{ fontSize: '14px' }}
            placeholder="Phase description..."
          />
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1.5 shrink-0 ml-2">
          <button
            onClick={() => onAddStep(phaseIndex)}
            className="w-7 h-7 bg-[#006B7D] rounded flex items-center justify-center text-white hover:bg-[#005568] transition-colors"
            title="Add step"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDeletePhase(phaseIndex)}
            className="text-red-500 hover:text-red-600 p-1 transition-colors"
            title="Delete phase"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Steps */}
      {!collapsed && (
        <div className="mx-3 mb-3 rounded-lg overflow-hidden border border-gray-200 bg-white">
          {phase.steps.map((step: any, stepIndex: number) => (
            <DraggableStep
              key={step.id}
              step={step}
              stepIndex={stepIndex}
              phaseIndex={phaseIndex}
              onUpdateStep={onUpdateStep}
              onDeleteStep={onDeleteStep}
              onMoveStep={onMoveStep}
              isLast={stepIndex === phase.steps.length - 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function EditPlaybook({ playbookId, onBack, onSave }: EditPlaybookProps) {
  const [playbookData, setPlaybookData] = useState(mockPlaybooks[playbookId] || mockPlaybooks[1]);
  const [hasChanges, setHasChanges] = useState(false);
  const [collapsedPhases, setCollapsedPhases] = useState<Record<number, boolean>>({});

  const togglePhase = (phaseIndex: number) => {
    setCollapsedPhases(prev => ({ ...prev, [phaseIndex]: !prev[phaseIndex] }));
  };

  const handleUpdateField = (field: string, value: any) => {
    setPlaybookData({ ...playbookData, [field]: value });
    setHasChanges(true);
  };

  const handleUpdatePhase = (phaseIndex: number, field: string, value: any) => {
    const newPhases = [...playbookData.phases];
    newPhases[phaseIndex] = {
      ...newPhases[phaseIndex],
      [field]: value,
    };
    handleUpdateField('phases', newPhases);
  };

  const handleUpdateStep = (phaseIndex: number, stepIndex: number, field: string, value: any) => {
    const newPhases = [...playbookData.phases];
    newPhases[phaseIndex].steps[stepIndex] = {
      ...newPhases[phaseIndex].steps[stepIndex],
      [field]: value,
    };
    handleUpdateField('phases', newPhases);
  };

  const handleAddPhase = () => {
    const newPhase = {
      id: Date.now(),
      name: 'New Phase',
      description: 'Phase description',
      steps: [],
    };
    handleUpdateField('phases', [...playbookData.phases, newPhase]);
  };

  const handleAddStep = (phaseIndex: number) => {
    const newPhases = [...playbookData.phases];
    const newStep = {
      id: Date.now(),
      name: 'New Step',
      description: 'Step description',
    };
    newPhases[phaseIndex].steps = [...newPhases[phaseIndex].steps, newStep];
    handleUpdateField('phases', newPhases);
  };

  const handleDeletePhase = (phaseIndex: number) => {
    const newPhases = playbookData.phases.filter((_: any, i: number) => i !== phaseIndex);
    handleUpdateField('phases', newPhases);
  };

  const handleDeleteStep = (phaseIndex: number, stepIndex: number) => {
    const newPhases = [...playbookData.phases];
    newPhases[phaseIndex].steps = newPhases[phaseIndex].steps.filter((_: any, i: number) => i !== stepIndex);
    handleUpdateField('phases', newPhases);
  };

  const handleMovePhase = (fromIndex: number, toIndex: number) => {
    const newPhases = [...playbookData.phases];
    const [movedPhase] = newPhases.splice(fromIndex, 1);
    newPhases.splice(toIndex, 0, movedPhase);
    handleUpdateField('phases', newPhases);
  };

  const handleMoveStep = (phaseIndex: number, fromIndex: number, toIndex: number) => {
    const newPhases = [...playbookData.phases];
    const steps = [...newPhases[phaseIndex].steps];
    const [movedStep] = steps.splice(fromIndex, 1);
    steps.splice(toIndex, 0, movedStep);
    newPhases[phaseIndex].steps = steps;
    handleUpdateField('phases', newPhases);
  };

  const handleSave = () => {
    setHasChanges(false);
    toast.success('Playbook saved successfully!');
    onSave();
  };

  const handleExport = (format: 'json' | 'csv' | 'text' | 'pdf') => {
    // Export logic here
    console.log(`Exporting as ${format}`);
    alert(`Exporting playbook as ${format.toUpperCase()}`);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-full flex flex-col bg-[#E8EDE8]">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-12 py-6">
          <button
            onClick={onBack}
            className="mb-4 flex items-center gap-1.5 text-[#006B7D] hover:text-[#005568] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Library
          </button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#006B7D] mb-2" style={{ fontSize: '28px', fontWeight: 600 }}>
                Edit Playbook
              </h1>
              <p className="text-gray-600 text-sm">
                Modify phases and steps for this playbook template
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Export Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="text-gray-600 border-gray-300 hover:border-[#006B7D] hover:text-[#006B7D]"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onSelect={() => handleExport('json')}>
                    <FileJson className="w-4 h-4 mr-2" />
                    Export as JSON
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => handleExport('csv')}>
                    <FileText className="w-4 h-4 mr-2" />
                    Export as CSV
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => handleExport('text')}>
                    <File className="w-4 h-4 mr-2" />
                    Export as Text
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => handleExport('pdf')}>
                    <FileText className="w-4 h-4 mr-2" />
                    Export as PDF
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                onClick={handleSave}
                className="bg-[#006B7D] hover:bg-[#005568] text-white px-6 gap-2"
              >
                <Save className="w-4 h-4" />
                Save Changes
                {hasChanges && <span className="ml-1 w-2 h-2 bg-amber-400 rounded-full"></span>}
              </Button>
            </div>
          </div>
        </div>

        {/* Editor Content */}
        <div className="flex-1 overflow-auto">
          <div className="max-w-[1400px] mx-auto px-12 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-[minmax(300px,_2fr)_3fr] gap-6 items-start">
              {/* Left — Details */}
              <div>
                <Card className="border-gray-200 sticky top-6">
                  <CardContent className="p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">
                      Playbook Details
                    </h2>

                    <div className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-4 items-center">
                      {/* Playbook Name */}
                      <Label htmlFor="playbookName" className="text-sm font-medium text-gray-700 text-right">
                        Name
                      </Label>
                      <Input
                        id="playbookName"
                        value={playbookData.name}
                        onChange={(e) => handleUpdateField('name', e.target.value)}
                        className="w-full"
                      />

                      {/* Description */}
                      <Label htmlFor="playbookDescription" className="text-sm font-medium text-gray-700 text-right self-start mt-2">
                        Description
                      </Label>
                      <Textarea
                        id="playbookDescription"
                        value={playbookData.description}
                        onChange={(e) => handleUpdateField('description', e.target.value)}
                        placeholder="Describe the purpose of this playbook..."
                        rows={3}
                        className="w-full resize-y"
                      />

                      {/* Owner */}
                      <Label htmlFor="owner" className="text-sm font-medium text-gray-700 text-right">
                        Owner
                      </Label>
                      <Input
                        id="owner"
                        value={playbookData.owner}
                        onChange={(e) => handleUpdateField('owner', e.target.value)}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right — Phases and Steps */}
              <div>
                <div className="space-y-4">
                  {playbookData.phases.map((phase: any, phaseIndex: number) => (
                    <DraggablePhase
                      key={phase.id}
                      phase={phase}
                      phaseIndex={phaseIndex}
                      onUpdatePhase={handleUpdatePhase}
                      onDeletePhase={handleDeletePhase}
                      onMovePhase={handleMovePhase}
                      onAddStep={handleAddStep}
                      onUpdateStep={handleUpdateStep}
                      onDeleteStep={handleDeleteStep}
                      onMoveStep={handleMoveStep}
                      collapsed={collapsedPhases[phaseIndex] || false}
                      onToggle={() => togglePhase(phaseIndex)}
                    />
                  ))}

                  {/* Add Phase Button */}
                  <Button
                    onClick={handleAddPhase}
                    variant="outline"
                    className="w-full border-2 border-dashed border-[#006B7D] text-[#006B7D] hover:bg-[#006B7D]/5 hover:text-[#005568] hover:border-[#005568] h-12"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Phase
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DndProvider>
  );
}