import { useState } from 'react';
import { Homepage } from './components/Homepage';
import { ProjectsOverview } from './components/ProjectsOverview';
import { CreateWorkflow } from './components/CreateWorkflow';
import { ViewPlaybook } from './components/ViewPlaybook';
import { InstancesLibrary } from './components/InstancesLibrary';
import { InstanceChecklist } from './components/InstanceChecklist';
import { EditPlaybook } from './components/EditPlaybook';
import { ViewRelatedInstances } from './components/ViewRelatedInstances';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'overview' | 'create' | 'view' | 'activePlaybooks' | 'activePlaybookChecklist' | 'editPlaybook' | 'viewRelated'>('home');
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | null>(null);
  const [selectedActivePlaybookId, setSelectedActivePlaybookId] = useState<number | null>(null);
  const [createOrigin, setCreateOrigin] = useState<'home' | 'overview'>('home');

  const handleViewPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('view');
  };

  const handleEditPlaybook = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('editPlaybook');
  };

  const handleViewRelated = (id: number) => {
    setSelectedPlaybookId(id);
    setCurrentView('viewRelated');
  };

  const handleActivePlaybookCreated = (activePlaybookId?: number) => {
    if (activePlaybookId) {
      setSelectedActivePlaybookId(activePlaybookId);
      setCurrentView('activePlaybookChecklist');
    } else {
      setCurrentView('activePlaybooks');
    }
  };

  const handleContinueActivePlaybook = (activePlaybookId: number) => {
    setSelectedActivePlaybookId(activePlaybookId);
    setCurrentView('activePlaybookChecklist');
  };

  return (
    <div className="size-full bg-[#E8EDE8]">
      {currentView === 'home' && (
        <Homepage 
          onNavigateToPlaybooks={() => setCurrentView('overview')}
          onNavigateToActivePlaybooks={() => setCurrentView('activePlaybooks')}
          onCreatePlaybook={() => { setCreateOrigin('home'); setCurrentView('create'); }}
        />
      )}
      {currentView === 'overview' && (
        <ProjectsOverview 
          onCreateNew={() => { setCreateOrigin('overview'); setCurrentView('create'); }} 
          onViewPlaybook={handleViewPlaybook}
          onEditPlaybook={handleEditPlaybook}
          onViewRelated={handleViewRelated}
          onActivePlaybookCreated={handleActivePlaybookCreated}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'create' && (
        <CreateWorkflow
          onBack={() => setCurrentView(createOrigin)}
          onSave={() => setCurrentView('overview')}
        />
      )}
      {currentView === 'view' && selectedPlaybookId && (
        <ViewPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')}
          onUsePlaybook={(playbookId) => {
            setSelectedActivePlaybookId(playbookId);
            setCurrentView('activePlaybookChecklist');
          }}
        />
      )}
      {currentView === 'editPlaybook' && selectedPlaybookId && (
        <EditPlaybook 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
          onSave={() => setCurrentView('overview')}
        />
      )}
      {currentView === 'viewRelated' && selectedPlaybookId && (
        <ViewRelatedInstances 
          playbookId={selectedPlaybookId} 
          onBack={() => setCurrentView('overview')} 
        />
      )}
      {currentView === 'activePlaybooks' && (
        <InstancesLibrary
          onCreateActivePlaybook={(playbookId) => {
            setSelectedPlaybookId(playbookId);
            setCurrentView('overview');
          }}
          onContinueActivePlaybook={handleContinueActivePlaybook}
          onBackHome={() => setCurrentView('home')}
        />
      )}
      {currentView === 'activePlaybookChecklist' && selectedActivePlaybookId && (
        <InstanceChecklist
          activePlaybookId={selectedActivePlaybookId}
          onBack={() => setCurrentView('activePlaybooks')}
        />
      )}
      <Toaster position="bottom-right" />
    </div>
  );
}