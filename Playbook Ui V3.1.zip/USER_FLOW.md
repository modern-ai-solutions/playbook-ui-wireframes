# Playbooks User Flow Documentation

## Overview
This document outlines the complete user flows for the Playbooks project management application focusing on process connections and functionality relationships.

---

## Primary User Flows

### 1. Homepage Entry Point
**Starting Point:** User lands on homepage

**Flow:**
1. User sees homepage with two main cards:
   - **Playbooks Library** - Browse and manage templates
   - **My Instances** - Track active playbook instances
2. User can click either card to navigate to respective library

---

### 2. Playbooks Library Flow

#### 2.1 Browse Playbooks
**Starting Point:** User navigates to Playbooks Library

**Flow:**
1. User lands on Playbooks Library page
2. User sees list/grid of available playbook templates
3. User can:
   - Search by name/description
   - Filter by category
   - Sort by newest/oldest/most used
   - Switch between grid and list views
   - Create new playbook template

#### 2.2 Create New Playbook Template
**Starting Point:** User is viewing Playbooks Library

**Flow:**
1. User clicks "Create New Playbook" button
2. System navigates to CreateWorkflow page
3. User provides:
   - Playbook name
   - Description
   - Category
   - Owner
   - Initial workflow structure (phases and steps)
4. User can:
   - Add/edit/delete phases
   - Add/edit/delete steps within phases
   - Reorder phases and steps via drag-and-drop
5. User clicks "Create Playbook"
6. System saves new playbook template
7. System returns to Playbooks Library showing the new template

#### 2.3 View Playbook Details
**Starting Point:** User is viewing Playbooks Library

**Flow:**
1. User clicks "View" button on a playbook card/row
2. System navigates to ViewPlaybook page showing:
   - Playbook metadata (name, description, category, owner)
   - Complete workflow breakdown with phases and steps
   - Usage statistics
   - Tags
3. User can:
   - Return to library
   - Start using the playbook (creates new instance)
   - Edit the template
   - View related instances
   - Export playbook data

#### 2.4 Create New Instance from Playbook
**Starting Point:** User is viewing a playbook

**Flow:**
1. User clicks "Use This Playbook" button
2. System opens ConfigureInstanceDialog
3. User configures instance (all fields optional):
   - Instance name
   - Owner
   - Due date
   - Description
4. User clicks "Create Instance"
5. System creates new instance from playbook template
6. System generates unique instance ID
7. System navigates directly to InstanceChecklist (active instance page)
8. User can immediately begin working on the instance workflow

#### 2.5 Edit Playbook Template
**Starting Point:** User is viewing a playbook

**Flow:**
1. User clicks "Edit Template" button
2. System navigates to EditPlaybook page
3. User sees editable form with:
   - Playbook metadata fields
   - Workflow editor with phases and steps
4. User can modify:
   - Playbook details
   - Workflow structure
   - Phase and step content
   - Reorder elements via drag-and-drop
5. User clicks "Save Changes"
6. System saves updates to template
7. System returns to ViewPlaybook page with updated data

#### 2.6 View Related Instances
**Starting Point:** User is viewing a playbook

**Flow:**
1. User clicks "View Related Instances" button
2. System navigates to ViewRelatedInstances page
3. User sees all instances created from this specific playbook template
4. User can:
   - Search/filter instances by status or name
   - Sort by date, progress, or other criteria
   - Switch between grid/list view
   - Continue working on an instance (→ InstanceChecklist)
   - Edit instance configuration (→ InstanceEditor)
   - Return to Playbooks Library

#### 2.7 Export Playbook
**Starting Point:** User is viewing Playbooks Library or ViewPlaybook page

**Flow:**
1. User clicks 3-dot menu on playbook
2. User clicks "Export" submenu
3. User selects export format (JSON, CSV, or Text)
4. System downloads playbook data in selected format

---

### 3. Instances Library Flow

#### 3.1 Browse Instances
**Starting Point:** User navigates to My Instances

**Flow:**
1. User lands on Instances Library page
2. User sees list/grid of active playbook instances
3. User can:
   - Search by instance name
   - Filter by status (Active, Completed)
   - Sort by due date, progress, or creation date
   - Switch between grid and list views

#### 3.2 Continue Instance
**Starting Point:** User is viewing Instances Library

**Flow:**
1. User clicks "Continue" button on instance
2. System navigates to InstanceChecklist page
3. User sees three-panel layout:
   - **Left**: Instance metadata and progress summary
   - **Center**: Workflow with phase cards and step checkboxes
   - **Right**: Activity panel with comments and history
4. User can:
   - Check/uncheck steps to mark completion
   - Add comments to document progress
   - View activity history
   - Progress bar updates automatically
5. User completes workflow over time
6. When all steps complete, instance status becomes "Done"

#### 3.3 Edit Instance Configuration
**Starting Point:** User is viewing Instances Library or InstanceChecklist

**Flow:**
1. User clicks "Edit" button
2. System navigates to InstanceEditor page
3. User can modify:
   - Instance metadata (name, owner, due date)
   - Workflow structure (add/remove/reorder phases and steps)
   - Step assignments and details
4. User clicks "Save Changes"
5. System updates instance configuration
6. System returns to previous page with updated data

#### 3.4 Export Instance
**Starting Point:** User is viewing Instances Library

**Flow:**
1. User clicks 3-dot menu on instance
2. User clicks "Export" submenu
3. User selects export format (JSON, CSV, or Text)
4. System downloads instance data including progress and completion status

#### 3.5 Additional Instance Actions
**Starting Point:** User is viewing Instances Library

**Flow:**
1. User clicks 3-dot menu on instance
2. User selects action:
   - **Duplicate**: Creates copy of instance with same structure
   - **Archive**: Moves instance to archived status
   - **Delete**: Opens confirmation dialog, then permanently deletes instance

---

## Secondary User Flows

### 4. Instance Checklist Interactions

#### 4.1 Complete Workflow Steps
**Starting Point:** User is on InstanceChecklist page

**Flow:**
1. User sees workflow organized by phases
2. Each phase contains multiple steps with checkboxes
3. User clicks checkbox to mark step complete
4. System updates:
   - Step status (checked/unchecked)
   - Phase progress
   - Overall instance progress bar
   - Activity log
5. Progress is saved automatically

#### 4.2 Add Comments
**Starting Point:** User is on InstanceChecklist page

**Flow:**
1. User clicks "Comments" tab in activity panel
2. User types comment in input field
3. User clicks "Post" or presses Enter
4. System adds comment to:
   - Comments tab
   - All Activities tab
5. Comment includes timestamp and author

#### 4.3 View Activity History
**Starting Point:** User is on InstanceChecklist page

**Flow:**
1. User clicks "History" tab in activity panel
2. User sees chronological log of all instance activities:
   - Step completions
   - Comments added
   - Instance configuration edits
   - Phase/step additions or deletions
3. Each entry shows timestamp and user who performed the action

---

## Navigation Structure

```
Homepage
├── Playbooks Library
│   ├── Create New Playbook (→ CreateWorkflow → Playbooks Library)
│   ├── View Playbook
│   │   ├── Start Using (→ ConfigureInstanceDialog → InstanceChecklist)
│   │   ├── Edit Template (→ EditPlaybook → ViewPlaybook)
│   │   └── View Related Instances (→ ViewRelatedInstances)
│   └── Export Playbook (downloads file)
│
└── My Instances
    ├── Continue Instance (→ InstanceChecklist)
    ├── Edit Instance (→ InstanceEditor → previous page)
    ├── Export Instance (downloads file)
    └── Duplicate/Archive/Delete Instance
```

---

## Process Connections

### Creating and Using Playbooks
1. **Create Template** (Playbooks Library → CreateWorkflow)
2. **Configure Template** (Add phases and steps)
3. **Save Template** (Returns to Playbooks Library)
4. **Start Using** (Click "Use This Playbook" → ConfigureInstanceDialog)
5. **Configure Instance** (Set optional metadata: owner, due date, description)
6. **Create & Navigate** (System creates instance and navigates to InstanceChecklist)
7. **Execute Workflow** (InstanceChecklist → Complete steps immediately)

### Iterating on Templates
1. **Review Usage** (View Related Instances)
2. **Identify Improvements** (See how instances are used)
3. **Edit Template** (EditPlaybook → Make changes)
4. **Save Updates** (Updated template available for new instances)
5. **Note**: Existing instances are not affected by template changes

### Managing Active Work
1. **Browse Instances** (Instances Library)
2. **Continue Work** (InstanceChecklist → Check off steps)
3. **Add Context** (Comments and activity)
4. **Adjust if Needed** (Edit instance configuration)
5. **Complete** (All steps checked → Status: Done)

---

## Key User Goals

1. **Create Reusable Templates**: Build standardized processes once, use many times
2. **Launch Instances**: Quickly start new instances from proven templates
3. **Track Progress**: Monitor workflow completion in real-time
4. **Collaborate**: Share context through comments and activity
5. **Adapt**: Customize workflows for specific situations
6. **Analyze**: Export data for external reporting

---

## Data Relationships

### Playbook Template → Instances
- One playbook template can create many instances
- Instances are copies, not references
- Changes to template don't affect existing instances
- "View Related Instances" shows all instances created from a template

### Instance Independence
- Each instance has its own workflow structure
- Can be customized without affecting the template
- Can be customized without affecting other instances
- Progress is tracked per instance

### User Ownership
- Playbooks have an owner (creator/maintainer)
- Instances have an owner (responsible party)
- Both can have different owners
- Comments/activity are attributed to specific users

---

## AI Generation Prompts

### For User Flow Diagrams
```
Create a user flow diagram for the Playbooks application based on USER_FLOW.md.
Show the relationships between:
- Homepage navigation
- Playbook creation and usage
- Instance configuration and execution
- Data export and management

Focus on: [SPECIFY FLOW, e.g., "2.4: Create New Instance from Playbook"]
```

### For Process Documentation
```
Generate process documentation for [SPECIFIC WORKFLOW] based on USER_FLOW.md.
Audience: Non-technical stakeholders
Focus on: Business workflow, decision points, outcomes
Exclude: Technical implementation details
```

### For Training Materials
```
Create a step-by-step tutorial for [USER GOAL] using USER_FLOW.md.
Include: Prerequisites, steps, expected outcomes, troubleshooting
Format: Easy-to-follow guide for new users
```

---

## Version History
- **v2.1** - Updated instance creation flow (March 18, 2026)
  - Modified flow 2.4: Instance creation now navigates directly to InstanceChecklist
  - All configuration fields in ConfigureInstanceDialog are now optional
  - Updated navigation structure and process connections diagrams
- **v2.0** - Streamlined process-focused documentation (March 18, 2026)
  - Added missing "Create New Playbook" flow
  - Removed visual design specifications
  - Focused on functional relationships and user processes
- **v1.0** - Initial user flow documentation